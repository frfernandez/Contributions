﻿namespace Sample
{
    partial class ItensMenuTabelasF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("DocumentosPessoais");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("DocumentosPessoaisVerificadores");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Documentos Pessoais", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("TitulosEnderecos");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Títulos", new System.Windows.Forms.TreeNode[] {
            treeNode4});
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Enderecos");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Endereços", new System.Windows.Forms.TreeNode[] {
            treeNode6});
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Bairros");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Bairros", new System.Windows.Forms.TreeNode[] {
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Cidades");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Cidades", new System.Windows.Forms.TreeNode[] {
            treeNode10});
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Estados");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Estados", new System.Windows.Forms.TreeNode[] {
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Paises");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Países", new System.Windows.Forms.TreeNode[] {
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Continentes");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Continentes", new System.Windows.Forms.TreeNode[] {
            treeNode16});
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("TiposTelefones");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Tipos de Telefones", new System.Windows.Forms.TreeNode[] {
            treeNode18});
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("TiposComunicacoes");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Tipos de Comunicações", new System.Windows.Forms.TreeNode[] {
            treeNode20});
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Contatos");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Contatos", new System.Windows.Forms.TreeNode[] {
            treeNode22});
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Agenda");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Agenda", new System.Windows.Forms.TreeNode[] {
            treeNode24});
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Cidades");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("CadastrosLocalidadesCidades");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Cidades", new System.Windows.Forms.TreeNode[] {
            treeNode26,
            treeNode27});
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Estados");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("CadastrosLocalidadesEstados");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Estados", new System.Windows.Forms.TreeNode[] {
            treeNode29,
            treeNode30});
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Paises");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("CadastrosLocalidadesPaises");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Países", new System.Windows.Forms.TreeNode[] {
            treeNode32,
            treeNode33});
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Contatos");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Continentes");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("CadastrosContatos");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Contatos", new System.Windows.Forms.TreeNode[] {
            treeNode35,
            treeNode36,
            treeNode37});
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Agenda");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("CadastrosAgenda");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Agenda", new System.Windows.Forms.TreeNode[] {
            treeNode39,
            treeNode40});
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("DocumentosPessoais");
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("DocumentosPessoaisVerificadores");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("Documentos Pessoais", new System.Windows.Forms.TreeNode[] {
            treeNode42,
            treeNode43});
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("TitulosEnderecos");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Títulos", new System.Windows.Forms.TreeNode[] {
            treeNode45});
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Enderecos");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("Endereços", new System.Windows.Forms.TreeNode[] {
            treeNode47});
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("Bairros");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("Bairros", new System.Windows.Forms.TreeNode[] {
            treeNode49});
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("Cidades");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("Cidades", new System.Windows.Forms.TreeNode[] {
            treeNode51});
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("Estados");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("Estados", new System.Windows.Forms.TreeNode[] {
            treeNode53});
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("Paises");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("Países", new System.Windows.Forms.TreeNode[] {
            treeNode55});
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("Continentes");
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("Continentes", new System.Windows.Forms.TreeNode[] {
            treeNode57});
            System.Windows.Forms.TreeNode treeNode59 = new System.Windows.Forms.TreeNode("TiposTelefones");
            System.Windows.Forms.TreeNode treeNode60 = new System.Windows.Forms.TreeNode("Tipos de Telefones", new System.Windows.Forms.TreeNode[] {
            treeNode59});
            System.Windows.Forms.TreeNode treeNode61 = new System.Windows.Forms.TreeNode("TiposComunicacoes");
            System.Windows.Forms.TreeNode treeNode62 = new System.Windows.Forms.TreeNode("Tipos de Comunicações", new System.Windows.Forms.TreeNode[] {
            treeNode61});
            System.Windows.Forms.TreeNode treeNode63 = new System.Windows.Forms.TreeNode("Contatos");
            System.Windows.Forms.TreeNode treeNode64 = new System.Windows.Forms.TreeNode("Continentes");
            System.Windows.Forms.TreeNode treeNode65 = new System.Windows.Forms.TreeNode("Contatos", new System.Windows.Forms.TreeNode[] {
            treeNode63,
            treeNode64});
            System.Windows.Forms.TreeNode treeNode66 = new System.Windows.Forms.TreeNode("Agenda");
            System.Windows.Forms.TreeNode treeNode67 = new System.Windows.Forms.TreeNode("Agenda", new System.Windows.Forms.TreeNode[] {
            treeNode66});
            System.Windows.Forms.TreeNode treeNode68 = new System.Windows.Forms.TreeNode("Acessos");
            System.Windows.Forms.TreeNode treeNode69 = new System.Windows.Forms.TreeNode("Acessos", new System.Windows.Forms.TreeNode[] {
            treeNode68});
            System.Windows.Forms.TreeNode treeNode70 = new System.Windows.Forms.TreeNode("Impressora");
            System.Windows.Forms.TreeNode treeNode71 = new System.Windows.Forms.TreeNode("Versão");
            System.Windows.Forms.TreeNode treeNode72 = new System.Windows.Forms.TreeNode("Texto");
            System.Windows.Forms.TreeNode treeNode73 = new System.Windows.Forms.TreeNode("Usuarios");
            System.Windows.Forms.TreeNode treeNode74 = new System.Windows.Forms.TreeNode("Equipamentos");
            System.Windows.Forms.TreeNode treeNode75 = new System.Windows.Forms.TreeNode("DiscosRigidos");
            System.Windows.Forms.TreeNode treeNode76 = new System.Windows.Forms.TreeNode("UsuariosDiscosRigidos");
            System.Windows.Forms.TreeNode treeNode77 = new System.Windows.Forms.TreeNode("Formularios");
            System.Windows.Forms.TreeNode treeNode78 = new System.Windows.Forms.TreeNode("Acessos");
            System.Windows.Forms.TreeNode treeNode79 = new System.Windows.Forms.TreeNode("Versao");
            System.Windows.Forms.TreeNode treeNode80 = new System.Windows.Forms.TreeNode("MenusMestresNomes");
            System.Windows.Forms.TreeNode treeNode81 = new System.Windows.Forms.TreeNode("MenusMestresRotulos");
            System.Windows.Forms.TreeNode treeNode82 = new System.Windows.Forms.TreeNode("MenusMestresNomesRotulos");
            System.Windows.Forms.TreeNode treeNode83 = new System.Windows.Forms.TreeNode("MenusDetalhesNomes");
            System.Windows.Forms.TreeNode treeNode84 = new System.Windows.Forms.TreeNode("MenusDetalhesRotulos");
            System.Windows.Forms.TreeNode treeNode85 = new System.Windows.Forms.TreeNode("MenusDetalhesNomesRotulos");
            System.Windows.Forms.TreeNode treeNode86 = new System.Windows.Forms.TreeNode("MenusMestresDetalhes");
            System.Windows.Forms.TreeNode treeNode87 = new System.Windows.Forms.TreeNode("MenusRelacionados");
            System.Windows.Forms.TreeNode treeNode88 = new System.Windows.Forms.TreeNode("TabelasMenu");
            System.Windows.Forms.TreeNode treeNode89 = new System.Windows.Forms.TreeNode("ConfiguracoesGlobais");
            System.Windows.Forms.TreeNode treeNode90 = new System.Windows.Forms.TreeNode("Relatorios");
            System.Windows.Forms.TreeNode treeNode91 = new System.Windows.Forms.TreeNode("Idiomas");
            System.Windows.Forms.TreeNode treeNode92 = new System.Windows.Forms.TreeNode("Rotulos");
            System.Windows.Forms.TreeNode treeNode93 = new System.Windows.Forms.TreeNode("Traducoes");
            System.Windows.Forms.TreeNode treeNode94 = new System.Windows.Forms.TreeNode("IdiomasRotulos");
            System.Windows.Forms.TreeNode treeNode95 = new System.Windows.Forms.TreeNode("ConsultasTipos");
            System.Windows.Forms.TreeNode treeNode96 = new System.Windows.Forms.TreeNode("ConsultasTiposExtensoes");
            System.Windows.Forms.TreeNode treeNode97 = new System.Windows.Forms.TreeNode("Consultas");
            System.Windows.Forms.TreeNode treeNode98 = new System.Windows.Forms.TreeNode("ConsultasExtensoes");
            System.Windows.Forms.TreeNode treeNode99 = new System.Windows.Forms.TreeNode("ConsultasVariaveis");
            System.Windows.Forms.TreeNode treeNode100 = new System.Windows.Forms.TreeNode("ConsultasVariaveisValores");
            System.Windows.Forms.TreeNode treeNode101 = new System.Windows.Forms.TreeNode("ConsultasDependenciasCampos");
            System.Windows.Forms.TreeNode treeNode102 = new System.Windows.Forms.TreeNode("ConsultasChecagens");
            System.Windows.Forms.TreeNode treeNode103 = new System.Windows.Forms.TreeNode("ConsultasGradeRotulos");
            System.Windows.Forms.TreeNode treeNode104 = new System.Windows.Forms.TreeNode("Permissoes");
            System.Windows.Forms.TreeNode treeNode105 = new System.Windows.Forms.TreeNode("CodigosOficiais");
            System.Windows.Forms.TreeNode treeNode106 = new System.Windows.Forms.TreeNode("Tabelas");
            System.Windows.Forms.TreeNode treeNode107 = new System.Windows.Forms.TreeNode("Campos");
            System.Windows.Forms.TreeNode treeNode108 = new System.Windows.Forms.TreeNode("TabelasCampos");
            System.Windows.Forms.TreeNode treeNode109 = new System.Windows.Forms.TreeNode("Impressos");
            System.Windows.Forms.TreeNode treeNode110 = new System.Windows.Forms.TreeNode("ConfiguracoesCodigos");
            System.Windows.Forms.TreeNode treeNode111 = new System.Windows.Forms.TreeNode("Procedimentos");
            System.Windows.Forms.TreeNode treeNode112 = new System.Windows.Forms.TreeNode("Parametros");
            System.Windows.Forms.TreeNode treeNode113 = new System.Windows.Forms.TreeNode("Arquivos");
            System.Windows.Forms.TreeNode treeNode114 = new System.Windows.Forms.TreeNode("ProcedimentosArquivosLeitura");
            System.Windows.Forms.TreeNode treeNode115 = new System.Windows.Forms.TreeNode("ProcedimentosArquivosLinhas");
            System.Windows.Forms.TreeNode treeNode116 = new System.Windows.Forms.TreeNode("ProcedimentosArquivosColunas");
            System.Windows.Forms.TreeNode treeNode117 = new System.Windows.Forms.TreeNode("PlanilhasTabelasCampos");
            System.Windows.Forms.TreeNode treeNode118 = new System.Windows.Forms.TreeNode("ProcedimentosPlanilhasCelulas");
            System.Windows.Forms.TreeNode treeNode119 = new System.Windows.Forms.TreeNode("ProcedimentosPlanilhasColunas");
            System.Windows.Forms.TreeNode treeNode120 = new System.Windows.Forms.TreeNode("Configuracoes");
            System.Windows.Forms.TreeNode treeNode121 = new System.Windows.Forms.TreeNode("ConsultasRealizadas");
            System.Windows.Forms.TreeNode treeNode122 = new System.Windows.Forms.TreeNode("ConsultasOrdens");
            System.Windows.Forms.TreeNode treeNode123 = new System.Windows.Forms.TreeNode("Papeis");
            System.Windows.Forms.TreeNode treeNode124 = new System.Windows.Forms.TreeNode("PapeisMenu");
            System.Windows.Forms.TreeNode treeNode125 = new System.Windows.Forms.TreeNode("DocumentosPessoais");
            System.Windows.Forms.TreeNode treeNode126 = new System.Windows.Forms.TreeNode("DocumentosPessoaisVerificadores");
            System.Windows.Forms.TreeNode treeNode127 = new System.Windows.Forms.TreeNode("Verificadores");
            System.Windows.Forms.TreeNode treeNode128 = new System.Windows.Forms.TreeNode("TiposObjetos");
            System.Windows.Forms.TreeNode treeNode129 = new System.Windows.Forms.TreeNode("Cores");
            System.Windows.Forms.TreeNode treeNode130 = new System.Windows.Forms.TreeNode("TiposObjetosCores");
            System.Windows.Forms.TreeNode treeNode131 = new System.Windows.Forms.TreeNode("Público", new System.Windows.Forms.TreeNode[] {
            treeNode73,
            treeNode74,
            treeNode75,
            treeNode76,
            treeNode77,
            treeNode78,
            treeNode79,
            treeNode80,
            treeNode81,
            treeNode82,
            treeNode83,
            treeNode84,
            treeNode85,
            treeNode86,
            treeNode87,
            treeNode88,
            treeNode89,
            treeNode90,
            treeNode91,
            treeNode92,
            treeNode93,
            treeNode94,
            treeNode95,
            treeNode96,
            treeNode97,
            treeNode98,
            treeNode99,
            treeNode100,
            treeNode101,
            treeNode102,
            treeNode103,
            treeNode104,
            treeNode105,
            treeNode106,
            treeNode107,
            treeNode108,
            treeNode109,
            treeNode110,
            treeNode111,
            treeNode112,
            treeNode113,
            treeNode114,
            treeNode115,
            treeNode116,
            treeNode117,
            treeNode118,
            treeNode119,
            treeNode120,
            treeNode121,
            treeNode122,
            treeNode123,
            treeNode124,
            treeNode125,
            treeNode126,
            treeNode127,
            treeNode128,
            treeNode129,
            treeNode130});
            System.Windows.Forms.TreeNode treeNode132 = new System.Windows.Forms.TreeNode("Conectar");
            System.Windows.Forms.TreeNode treeNode133 = new System.Windows.Forms.TreeNode("Conectar Como...");
            System.Windows.Forms.TreeNode treeNode134 = new System.Windows.Forms.TreeNode("Desconectar");
            System.Windows.Forms.TreeNode treeNode135 = new System.Windows.Forms.TreeNode("Enderecos");
            System.Windows.Forms.TreeNode treeNode136 = new System.Windows.Forms.TreeNode("Bairros");
            System.Windows.Forms.TreeNode treeNode137 = new System.Windows.Forms.TreeNode("Cidades");
            System.Windows.Forms.TreeNode treeNode138 = new System.Windows.Forms.TreeNode("Estados");
            System.Windows.Forms.TreeNode treeNode139 = new System.Windows.Forms.TreeNode("Paises");
            System.Windows.Forms.TreeNode treeNode140 = new System.Windows.Forms.TreeNode("Continentes");
            System.Windows.Forms.TreeNode treeNode141 = new System.Windows.Forms.TreeNode("TiposTelefones");
            System.Windows.Forms.TreeNode treeNode142 = new System.Windows.Forms.TreeNode("TiposComunicacoes");
            System.Windows.Forms.TreeNode treeNode143 = new System.Windows.Forms.TreeNode("Contatos");
            System.Windows.Forms.TreeNode treeNode144 = new System.Windows.Forms.TreeNode("DocumentosPessoais");
            System.Windows.Forms.TreeNode treeNode145 = new System.Windows.Forms.TreeNode("ConfiguracoesCodigos");
            System.Windows.Forms.TreeNode treeNode146 = new System.Windows.Forms.TreeNode("Configurações", new System.Windows.Forms.TreeNode[] {
            treeNode135,
            treeNode136,
            treeNode137,
            treeNode138,
            treeNode139,
            treeNode140,
            treeNode141,
            treeNode142,
            treeNode143,
            treeNode144,
            treeNode145});
            this.PnlArvore = new System.Windows.Forms.Panel();
            this.TrVItensMenusTabelas = new System.Windows.Forms.TreeView();
            this.PnlMedidor = new System.Windows.Forms.Panel();
            this.PrBMedidor = new System.Windows.Forms.ProgressBar();
            this.PnlArvore.SuspendLayout();
            this.PnlMedidor.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlArvore
            // 
            this.PnlArvore.Controls.Add(this.TrVItensMenusTabelas);
            this.PnlArvore.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlArvore.Location = new System.Drawing.Point(0, 0);
            this.PnlArvore.Name = "PnlArvore";
            this.PnlArvore.Size = new System.Drawing.Size(284, 10);
            this.PnlArvore.TabIndex = 0;
            this.PnlArvore.Visible = false;
            // 
            // TrVItensMenusTabelas
            // 
            this.TrVItensMenusTabelas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TrVItensMenusTabelas.Location = new System.Drawing.Point(0, 0);
            this.TrVItensMenusTabelas.Name = "TrVItensMenusTabelas";
            treeNode1.Name = "DocumentosPessoais";
            treeNode1.Text = "DocumentosPessoais";
            treeNode2.Name = "DocumentosPessoaisVerificadores";
            treeNode2.Tag = "IE";
            treeNode2.Text = "DocumentosPessoaisVerificadores";
            treeNode3.Name = "CadastrosDocumentosPessoais";
            treeNode3.Tag = "IAE";
            treeNode3.Text = "Documentos Pessoais";
            treeNode4.Name = "TitulosEnderecos";
            treeNode4.Text = "TitulosEnderecos";
            treeNode5.Name = "CadastrosLocalidadesTitulos";
            treeNode5.Tag = "IAE";
            treeNode5.Text = "Títulos";
            treeNode6.Name = "Enderecos";
            treeNode6.Text = "Enderecos";
            treeNode7.Name = "CadastrosLocalidadesEnderecos";
            treeNode7.Tag = "IAE";
            treeNode7.Text = "Endereços";
            treeNode8.Name = "Bairros";
            treeNode8.Text = "Bairros";
            treeNode9.Name = "CadastrosLocalidadesBairros";
            treeNode9.Tag = "IAE";
            treeNode9.Text = "Bairros";
            treeNode10.Name = "Cidades";
            treeNode10.Text = "Cidades";
            treeNode11.Name = "CadastrosLocalidadesCidades";
            treeNode11.Tag = "IAE";
            treeNode11.Text = "Cidades";
            treeNode12.Name = "Estados";
            treeNode12.Text = "Estados";
            treeNode13.Name = "CadastrosLocalidadesEstados";
            treeNode13.Tag = "IAE";
            treeNode13.Text = "Estados";
            treeNode14.Name = "Paises";
            treeNode14.Text = "Paises";
            treeNode15.Name = "CadastrosLocalidadesPaises";
            treeNode15.Tag = "IAE";
            treeNode15.Text = "Países";
            treeNode16.Name = "Continentes";
            treeNode16.Text = "Continentes";
            treeNode17.Name = "CadastrosLocalidadesContinentes";
            treeNode17.Tag = "IAE";
            treeNode17.Text = "Continentes";
            treeNode18.Name = "TiposTelefones";
            treeNode18.Text = "TiposTelefones";
            treeNode19.Name = "CadastrosComunicacoesTiposTelefones";
            treeNode19.Tag = "IAE";
            treeNode19.Text = "Tipos de Telefones";
            treeNode20.Name = "TiposComunicacoes";
            treeNode20.Text = "TiposComunicacoes";
            treeNode21.Name = "CadastrosComunicacoesTiposComunicacoes";
            treeNode21.Tag = "IAE";
            treeNode21.Text = "Tipos de Comunicações";
            treeNode22.Name = "Contatos";
            treeNode22.Text = "Contatos";
            treeNode23.Name = "CadastrosContatos";
            treeNode23.Tag = "IAE";
            treeNode23.Text = "Contatos";
            treeNode24.Name = "Agenda";
            treeNode24.Text = "Agenda";
            treeNode25.Name = "CadastrosAgenda";
            treeNode25.Tag = "IAE";
            treeNode25.Text = "Agenda";
            treeNode26.Name = "Cidades";
            treeNode26.Text = "Cidades";
            treeNode27.Name = "CadastrosLocalidadesCidades";
            treeNode27.Tag = "MN";
            treeNode27.Text = "CadastrosLocalidadesCidades";
            treeNode28.Name = "ConsultasLocalidadesCidades";
            treeNode28.Tag = "C";
            treeNode28.Text = "Cidades";
            treeNode29.Name = "Estados";
            treeNode29.Text = "Estados";
            treeNode30.Name = "CadastrosLocalidadesEstados";
            treeNode30.Tag = "MN";
            treeNode30.Text = "CadastrosLocalidadesEstados";
            treeNode31.Name = "ConsultasLocalidadesEstados";
            treeNode31.Tag = "C";
            treeNode31.Text = "Estados";
            treeNode32.Name = "Paises";
            treeNode32.Text = "Paises";
            treeNode33.Name = "CadastrosLocalidadesPaises";
            treeNode33.Tag = "MN";
            treeNode33.Text = "CadastrosLocalidadesPaises";
            treeNode34.Name = "ConsultasLocalidadesPaises";
            treeNode34.Tag = "C";
            treeNode34.Text = "Países";
            treeNode35.Name = "Contatos";
            treeNode35.Text = "Contatos";
            treeNode36.Name = "Continentes";
            treeNode36.Tag = "C";
            treeNode36.Text = "Continentes";
            treeNode37.Name = "CadastrosContatos";
            treeNode37.Tag = "MN";
            treeNode37.Text = "CadastrosContatos";
            treeNode38.Name = "ConsultasContatos";
            treeNode38.Tag = "C";
            treeNode38.Text = "Contatos";
            treeNode39.Name = "Agenda";
            treeNode39.Text = "Agenda";
            treeNode40.Name = "CadastrosAgenda";
            treeNode40.Tag = "MN";
            treeNode40.Text = "CadastrosAgenda";
            treeNode41.Name = "ConsultasAgenda";
            treeNode41.Tag = "C";
            treeNode41.Text = "Agenda";
            treeNode42.Name = "DocumentosPessoais";
            treeNode42.Text = "DocumentosPessoais";
            treeNode43.Name = "DocumentosPessoaisVerificadores";
            treeNode43.Text = "DocumentosPessoaisVerificadores";
            treeNode44.Name = "RelatoriosDocumentosPessoais";
            treeNode44.Tag = "R";
            treeNode44.Text = "Documentos Pessoais";
            treeNode45.Name = "TitulosEnderecos";
            treeNode45.Text = "TitulosEnderecos";
            treeNode46.Name = "RelatoriosTitulosEnderecos";
            treeNode46.Tag = "R";
            treeNode46.Text = "Títulos";
            treeNode47.Name = "Enderecos";
            treeNode47.Text = "Enderecos";
            treeNode48.Name = "RelatoriosEnderecos";
            treeNode48.Tag = "R";
            treeNode48.Text = "Endereços";
            treeNode49.Name = "Bairros";
            treeNode49.Text = "Bairros";
            treeNode50.Name = "RelatoriosBairros";
            treeNode50.Tag = "R";
            treeNode50.Text = "Bairros";
            treeNode51.Name = "Cidades";
            treeNode51.Text = "Cidades";
            treeNode52.Name = "RelatoriosCidades";
            treeNode52.Tag = "R";
            treeNode52.Text = "Cidades";
            treeNode53.Name = "Estados";
            treeNode53.Text = "Estados";
            treeNode54.Name = "RelatoriosEstados";
            treeNode54.Tag = "R";
            treeNode54.Text = "Estados";
            treeNode55.Name = "Paises";
            treeNode55.Text = "Paises";
            treeNode56.Name = "RelatoriosPaises";
            treeNode56.Tag = "R";
            treeNode56.Text = "Países";
            treeNode57.Name = "Continentes";
            treeNode57.Text = "Continentes";
            treeNode58.Name = "RelatoriosContinentes";
            treeNode58.Tag = "R";
            treeNode58.Text = "Continentes";
            treeNode59.Name = "TiposTelefones";
            treeNode59.Text = "TiposTelefones";
            treeNode60.Name = "RelatoriosTiposTelefones";
            treeNode60.Tag = "R";
            treeNode60.Text = "Tipos de Telefones";
            treeNode61.Name = "TiposComunicacoes";
            treeNode61.Text = "TiposComunicacoes";
            treeNode62.Name = "RelatoriosTiposComunicacoes";
            treeNode62.Tag = "R";
            treeNode62.Text = "Tipos de Comunicações";
            treeNode63.Name = "Contatos";
            treeNode63.Text = "Contatos";
            treeNode64.Name = "Continentes";
            treeNode64.Tag = "C";
            treeNode64.Text = "Continentes";
            treeNode65.Name = "RelatoriosContatos";
            treeNode65.Tag = "R";
            treeNode65.Text = "Contatos";
            treeNode66.Name = "Agenda";
            treeNode66.Text = "Agenda";
            treeNode67.Name = "RelatoriosAgenda";
            treeNode67.Tag = "R";
            treeNode67.Text = "Agenda";
            treeNode68.Name = "Acessos";
            treeNode68.Text = "Acessos";
            treeNode69.Name = "RelatoriosAcessos";
            treeNode69.Tag = "R";
            treeNode69.Text = "Acessos";
            treeNode70.Name = "UtilitariosImpressora";
            treeNode70.Tag = "U";
            treeNode70.Text = "Impressora";
            treeNode71.Name = "UtilitariosVersao";
            treeNode71.Tag = "U";
            treeNode71.Text = "Versão";
            treeNode72.Name = "UtilitariosTexto";
            treeNode72.Tag = "U";
            treeNode72.Text = "Texto";
            treeNode73.Name = "Usuarios";
            treeNode73.Tag = "IC";
            treeNode73.Text = "Usuarios";
            treeNode74.Name = "Equipamentos";
            treeNode74.Tag = "I";
            treeNode74.Text = "Equipamentos";
            treeNode75.Name = "DiscosRigidos";
            treeNode75.Tag = "I";
            treeNode75.Text = "DiscosRigidos";
            treeNode76.Name = "UsuariosDiscosRigidos";
            treeNode76.Tag = "I";
            treeNode76.Text = "UsuariosDiscosRigidos";
            treeNode77.Name = "Formularios";
            treeNode77.Tag = "I";
            treeNode77.Text = "Formularios";
            treeNode78.Name = "Acessos";
            treeNode78.Tag = "I";
            treeNode78.Text = "Acessos";
            treeNode79.Name = "Versao";
            treeNode79.Tag = "C";
            treeNode79.Text = "Versao";
            treeNode80.Name = "MenusMestresNomes";
            treeNode80.Tag = "C";
            treeNode80.Text = "MenusMestresNomes";
            treeNode81.Name = "MenusMestresRotulos";
            treeNode81.Tag = "C";
            treeNode81.Text = "MenusMestresRotulos";
            treeNode82.Name = "MenusMestresNomesRotulos";
            treeNode82.Tag = "C";
            treeNode82.Text = "MenusMestresNomesRotulos";
            treeNode83.Name = "MenusDetalhesNomes";
            treeNode83.Tag = "C";
            treeNode83.Text = "MenusDetalhesNomes";
            treeNode84.Name = "MenusDetalhesRotulos";
            treeNode84.Tag = "C";
            treeNode84.Text = "MenusDetalhesRotulos";
            treeNode85.Name = "MenusDetalhesNomesRotulos";
            treeNode85.Tag = "C";
            treeNode85.Text = "MenusDetalhesNomesRotulos";
            treeNode86.Name = "MenusMestresDetalhes";
            treeNode86.Tag = "C";
            treeNode86.Text = "MenusMestresDetalhes";
            treeNode87.Name = "MenusRelacionados";
            treeNode87.Tag = "C";
            treeNode87.Text = "MenusRelacionados";
            treeNode88.Name = "TabelasMenu";
            treeNode88.Tag = "C";
            treeNode88.Text = "TabelasMenu";
            treeNode89.Name = "ConfiguracoesGlobais";
            treeNode89.Tag = "C";
            treeNode89.Text = "ConfiguracoesGlobais";
            treeNode90.Name = "Relatorios";
            treeNode90.Tag = "C";
            treeNode90.Text = "Relatorios";
            treeNode91.Name = "Idiomas";
            treeNode91.Tag = "C";
            treeNode91.Text = "Idiomas";
            treeNode92.Name = "Rotulos";
            treeNode92.Tag = "IC";
            treeNode92.Text = "Rotulos";
            treeNode93.Name = "Traducoes";
            treeNode93.Tag = "C";
            treeNode93.Text = "Traducoes";
            treeNode94.Name = "IdiomasRotulos";
            treeNode94.Tag = "C";
            treeNode94.Text = "IdiomasRotulos";
            treeNode95.Name = "ConsultasTipos";
            treeNode95.Tag = "C";
            treeNode95.Text = "ConsultasTipos";
            treeNode96.Name = "ConsultasTiposExtensoes";
            treeNode96.Tag = "C";
            treeNode96.Text = "ConsultasTiposExtensoes";
            treeNode97.Name = "Consultas";
            treeNode97.Tag = "C";
            treeNode97.Text = "Consultas";
            treeNode98.Name = "ConsultasExtensoes";
            treeNode98.Tag = "C";
            treeNode98.Text = "ConsultasExtensoes";
            treeNode99.Name = "ConsultasVariaveis";
            treeNode99.Tag = "C";
            treeNode99.Text = "ConsultasVariaveis";
            treeNode100.Name = "ConsultasVariaveisValores";
            treeNode100.Tag = "C";
            treeNode100.Text = "ConsultasVariaveisValores";
            treeNode101.Name = "ConsultasDependenciasCampos";
            treeNode101.Tag = "C";
            treeNode101.Text = "ConsultasDependenciasCampos";
            treeNode102.Name = "ConsultasChecagens";
            treeNode102.Tag = "C";
            treeNode102.Text = "ConsultasChecagens";
            treeNode103.Name = "ConsultasGradeRotulos";
            treeNode103.Tag = "C";
            treeNode103.Text = "ConsultasGradeRotulos";
            treeNode104.Name = "Permissoes";
            treeNode104.Tag = "C";
            treeNode104.Text = "Permissoes";
            treeNode105.Name = "CodigosOficiais";
            treeNode105.Tag = "IA";
            treeNode105.Text = "CodigosOficiais";
            treeNode106.Name = "Tabelas";
            treeNode106.Tag = "C";
            treeNode106.Text = "Tabelas";
            treeNode107.Name = "Campos";
            treeNode107.Tag = "C";
            treeNode107.Text = "Campos";
            treeNode108.Name = "TabelasCampos";
            treeNode108.Tag = "C";
            treeNode108.Text = "TabelasCampos";
            treeNode109.Name = "Impressos";
            treeNode109.Tag = "C";
            treeNode109.Text = "Impressos";
            treeNode110.Name = "ConfiguracoesCodigos";
            treeNode110.Tag = "IE";
            treeNode110.Text = "ConfiguracoesCodigos";
            treeNode111.Name = "Procedimentos";
            treeNode111.Tag = "C";
            treeNode111.Text = "Procedimentos";
            treeNode112.Name = "Parametros";
            treeNode112.Tag = "C";
            treeNode112.Text = "Parametros";
            treeNode113.Name = "Arquivos";
            treeNode113.Tag = "IAE";
            treeNode113.Text = "Arquivos";
            treeNode114.Name = "ProcedimentosArquivosLeitura";
            treeNode114.Tag = "IE";
            treeNode114.Text = "ProcedimentosArquivosLeitura";
            treeNode115.Name = "ProcedimentosArquivosLinhas";
            treeNode115.Tag = "IE";
            treeNode115.Text = "ProcedimentosArquivosLinhas";
            treeNode116.Name = "ProcedimentosArquivosColunas";
            treeNode116.Tag = "IE";
            treeNode116.Text = "ProcedimentosArquivosColunas";
            treeNode117.Name = "PlanilhasTabelasCampos";
            treeNode117.Tag = "IE";
            treeNode117.Text = "PlanilhasTabelasCampos";
            treeNode118.Name = "ProcedimentosPlanilhasCelulas";
            treeNode118.Tag = "IE";
            treeNode118.Text = "ProcedimentosPlanilhasCelulas";
            treeNode119.Name = "ProcedimentosPlanilhasColunas";
            treeNode119.Tag = "IE";
            treeNode119.Text = "ProcedimentosPlanilhasColunas";
            treeNode120.Name = "Configuracoes";
            treeNode120.Tag = "T";
            treeNode120.Text = "Configuracoes";
            treeNode121.Name = "ConsultasRealizadas";
            treeNode121.Tag = "IE";
            treeNode121.Text = "ConsultasRealizadas";
            treeNode122.Name = "ConsultasOrdens";
            treeNode122.Tag = "T";
            treeNode122.Text = "ConsultasOrdens";
            treeNode123.Name = "Papeis";
            treeNode123.Tag = "C";
            treeNode123.Text = "Papeis";
            treeNode124.Name = "PapeisMenu";
            treeNode124.Tag = "C";
            treeNode124.Text = "PapeisMenu";
            treeNode125.Name = "DocumentosPessoais";
            treeNode125.Tag = "C";
            treeNode125.Text = "DocumentosPessoais";
            treeNode126.Name = "DocumentosPessoaisVerificadores";
            treeNode126.Tag = "C";
            treeNode126.Text = "DocumentosPessoaisVerificadores";
            treeNode127.Name = "Verificadores";
            treeNode127.Tag = "C";
            treeNode127.Text = "Verificadores";
            treeNode128.Name = "TiposObjetos";
            treeNode128.Tag = "I";
            treeNode128.Text = "TiposObjetos";
            treeNode129.Name = "Cores";
            treeNode129.Tag = "I";
            treeNode129.Text = "Cores";
            treeNode130.Name = "TiposObjetosCores";
            treeNode130.Tag = "IE";
            treeNode130.Text = "TiposObjetosCores";
            treeNode131.Name = "UtilitariosPublico";
            treeNode131.Tag = "U";
            treeNode131.Text = "Público";
            treeNode132.Name = "ConexaoConectar";
            treeNode132.Tag = "X";
            treeNode132.Text = "Conectar";
            treeNode133.Name = "ConexaoConectarComo";
            treeNode133.Tag = "X";
            treeNode133.Text = "Conectar Como...";
            treeNode134.Name = "ConexaoDesconectar";
            treeNode134.Tag = "X";
            treeNode134.Text = "Desconectar";
            treeNode135.Name = "Enderecos";
            treeNode135.Tag = "C";
            treeNode135.Text = "Enderecos";
            treeNode136.Name = "Bairros";
            treeNode136.Tag = "C";
            treeNode136.Text = "Bairros";
            treeNode137.Name = "Cidades";
            treeNode137.Tag = "C";
            treeNode137.Text = "Cidades";
            treeNode138.Name = "Estados";
            treeNode138.Tag = "C";
            treeNode138.Text = "Estados";
            treeNode139.Name = "Paises";
            treeNode139.Tag = "C";
            treeNode139.Text = "Paises";
            treeNode140.Name = "Continentes";
            treeNode140.Tag = "C";
            treeNode140.Text = "Continentes";
            treeNode141.Name = "TiposTelefones";
            treeNode141.Tag = "C";
            treeNode141.Text = "TiposTelefones";
            treeNode142.Name = "TiposComunicacoes";
            treeNode142.Tag = "C";
            treeNode142.Text = "TiposComunicacoes";
            treeNode143.Name = "Contatos";
            treeNode143.Tag = "C";
            treeNode143.Text = "Contatos";
            treeNode144.Name = "DocumentosPessoais";
            treeNode144.Tag = "C";
            treeNode144.Text = "DocumentosPessoais";
            treeNode145.Name = "ConfiguracoesCodigos";
            treeNode145.Tag = "IE";
            treeNode145.Text = "ConfiguracoesCodigos";
            treeNode146.Name = "ConexaoConfiguracoes";
            treeNode146.Tag = "X";
            treeNode146.Text = "Configurações";
            this.TrVItensMenusTabelas.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode5,
            treeNode7,
            treeNode9,
            treeNode11,
            treeNode13,
            treeNode15,
            treeNode17,
            treeNode19,
            treeNode21,
            treeNode23,
            treeNode25,
            treeNode28,
            treeNode31,
            treeNode34,
            treeNode38,
            treeNode41,
            treeNode44,
            treeNode46,
            treeNode48,
            treeNode50,
            treeNode52,
            treeNode54,
            treeNode56,
            treeNode58,
            treeNode60,
            treeNode62,
            treeNode65,
            treeNode67,
            treeNode69,
            treeNode70,
            treeNode71,
            treeNode72,
            treeNode131,
            treeNode132,
            treeNode133,
            treeNode134,
            treeNode146});
            this.TrVItensMenusTabelas.Size = new System.Drawing.Size(284, 10);
            this.TrVItensMenusTabelas.TabIndex = 11;
            // 
            // PnlMedidor
            // 
            this.PnlMedidor.Controls.Add(this.PrBMedidor);
            this.PnlMedidor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlMedidor.Location = new System.Drawing.Point(0, 10);
            this.PnlMedidor.Name = "PnlMedidor";
            this.PnlMedidor.Size = new System.Drawing.Size(284, 15);
            this.PnlMedidor.TabIndex = 1;
            // 
            // PrBMedidor
            // 
            this.PrBMedidor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PrBMedidor.Location = new System.Drawing.Point(0, 0);
            this.PrBMedidor.Name = "PrBMedidor";
            this.PrBMedidor.Size = new System.Drawing.Size(284, 15);
            this.PrBMedidor.TabIndex = 0;
            // 
            // ItensMenuTabelasF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 25);
            this.Controls.Add(this.PnlMedidor);
            this.Controls.Add(this.PnlArvore);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ItensMenuTabelasF";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tabelas dos Itens de Menu";
            this.Shown += new System.EventHandler(this.ItensMenuTabelasF_Shown);
            this.PnlArvore.ResumeLayout(false);
            this.PnlMedidor.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlArvore;
        private System.Windows.Forms.TreeView TrVItensMenusTabelas;
        private System.Windows.Forms.Panel PnlMedidor;
        private System.Windows.Forms.ProgressBar PrBMedidor;

    }
}