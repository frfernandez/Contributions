﻿using System.Windows.Forms;

namespace Sample
{
    public partial class ItensMenuTabelasF : Form
    {
        public ItensMenuTabelasF()
        {
            InitializeComponent();
        }

        private void ItensMenuTabelasF_Shown(object sender, System.EventArgs e)
        {
            string[] Texto;

            Texto = RegistrosDesktop.TabelasItensMenu(Conectar.CaixaPretaArquivo, TrVItensMenusTabelas, PrBMedidor);

            if (Texto.Length > 0)
            {
                using (TextoF Formulario = new TextoF())
                {
                    Formulario.Texto = Texto;
                    Formulario.ShowDialog();
                    Formulario.Dispose();
                }
            }
        }
    }
}