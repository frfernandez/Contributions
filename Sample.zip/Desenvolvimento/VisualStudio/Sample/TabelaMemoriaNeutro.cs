﻿using System;
using System.Data;

namespace Sample
{
    public sealed class TabelaMemoriaNeutro
    {
        public static DataTable CriarTabelaConfiguracoes()
        {
            DataTable Retorno = new DataTable("Configuracoes");

            DataColumn Tipo = new DataColumn("Tipo", typeof(string));
            Tipo.MaxLength = 1000;
            Tipo.AllowDBNull = false;
            Tipo.Caption = "Tipos";

            DataColumn Parametro = new DataColumn("Parametro", typeof(string));
            Parametro.MaxLength = 1000;
            Parametro.AllowDBNull = false;
            Parametro.Caption = "Parâmetros";

            DataColumn Valor = new DataColumn("Valor", typeof(string[]));
            Valor.AllowDBNull = true;
            Valor.Caption = "Valores";

            Retorno.Columns.Add(Tipo);
            Retorno.Columns.Add(Parametro);
            Retorno.Columns.Add(Valor);

            Retorno = TabelaMemoriaNeutro.ChavePrimaria(Retorno, "Tipo;Parametro");

            return Retorno;
        }

        public static DataTable ChavePrimaria(DataTable Tabela, string Coluna)
        {
            DataTable Retorno = Tabela;
            string[] MatrizColuna = Matriz.Configurar(";", Coluna);

            DataColumn[] ChavePrimaria = new DataColumn[MatrizColuna.Length];
            for (int i = 0; i < ChavePrimaria.Length; i++)
                ChavePrimaria[i] = Retorno.Columns[MatrizColuna[i]];

            Retorno.PrimaryKey = ChavePrimaria;

            return Retorno;
        }

        public static DataRow Posicionar(DataTable Tabela, string Pesquisa)
        {
            DataRow Retorno = null;
            string[] PesquisaMatriz = Matriz.Configurar("|", Pesquisa);

            Object[] ConsultaComposta = new Object[Tabela.PrimaryKey.Length];
            for (int i = 0; i < ConsultaComposta.Length; i++)
                ConsultaComposta[i] = PesquisaMatriz[i];

            Retorno = Tabela.Rows.Find(ConsultaComposta);

            return Retorno;
        }

        public static string ComandoFiltrar(DataTable TabelaConfigurar, string Campo, string Pesquisa)
        {
            string Retorno = "";
            string[] MatrizCampo = Matriz.Configurar(";", Campo),
                     MatrizPesquisa = Matriz.Configurar(";", Pesquisa);

            for (int i = 0; i < MatrizCampo.Length; i++)
            {
                Retorno = String.Concat(Retorno, MatrizCampo[i].ToString(), " = '{", i.ToString(), "}'");
                if (i < MatrizCampo.Length - 1)
                    Retorno = String.Concat(Retorno, " And ");
            }

            Retorno = string.Format(Retorno, MatrizPesquisa);

            return Retorno;
        }

        public static void Cadastrar(DataTable Tabela, DataRow Registro, bool Incluir, bool Alterado)
        {
            if (Incluir == true)
                Tabela.Rows.Add(Registro);
            else
            {
                if (Alterado == true)
                    Tabela.AcceptChanges();
            }
        }

        public static void CadastrarUnico(DataTable Tabela, string Valor)
        {
            string[] InclusaoMatriz = Matriz.Configurar("|", Valor);

            if (InclusaoMatriz.Length <= Tabela.Columns.Count)
            {
                bool Incluir = false,
                     Alterado = false;

                DataRow Registro = Posicionar(Tabela, Valor);
                if (Registro == null)
                {
                    Registro = Tabela.NewRow();
                    Incluir = true;
                }

                for (int i = 0; i < InclusaoMatriz.Length; i++)
                {
                    if (Registro[i].ToString() != InclusaoMatriz[i].ToString())
                    {
                        Registro[i] = InclusaoMatriz[i];

                        if (Incluir == false)
                            Alterado = true;
                    }
                }

                Cadastrar(Tabela, Registro, Incluir, Alterado);
            }
        }

        public static void CadastrarMatriz(DataTable Tabela, string Valor)
        {
            string[] InclusaoMatriz = Matriz.Configurar("|", Valor);

            if (InclusaoMatriz.Length <= Tabela.Columns.Count)
            {
                bool Incluir = false,
                     Alterado = false;

                DataRow Registro = Posicionar(Tabela, Valor);
                if (Registro == null)
                {
                    Registro = Tabela.NewRow();
                    Incluir = true;
                }

                for (int i = 0; i < InclusaoMatriz.Length; i++)
                {
                    if (i <= InclusaoMatriz.Length - 2)
                    {
                        if (Registro[i].ToString() != InclusaoMatriz[i].ToString())
                        {
                            Registro[i] = InclusaoMatriz[i];

                            if (Incluir == false)
                                Alterado = true;
                        }
                    }
                    else
                    {
                        string[] RegistroLeitura = null;
                        string[] RegistroCadastro = new string[1] { InclusaoMatriz[i] };

                        if (String.IsNullOrEmpty(Registro[i].ToString()) == false)
                            RegistroLeitura = (string[])Registro[i];

                        if (RegistroLeitura == null)
                            Registro[i] = RegistroCadastro;
                        else
                        {
                            if (RegistroLeitura[0].ToString() != InclusaoMatriz[i].ToString())
                            {
                                Registro[i] = RegistroCadastro;

                                if (Incluir == false)
                                    Alterado = true;
                            }
                        }
                    }
                }

                Cadastrar(Tabela, Registro, Incluir, Alterado);
            }
        }

        public static void CadastrarMatriz(DataTable Tabela, string ValorCaracter, string[] ValorMatriz)
        {
            string[] InclusaoMatriz = Matriz.Configurar("|", ValorCaracter);
            string ColunaValor = Tabela.Columns[Tabela.Columns.Count - 1].ColumnName;

            if (InclusaoMatriz.Length <= Tabela.Columns.Count)
            {
                bool Incluir = false,
                     Alterado = false;

                DataRow Registro = Posicionar(Tabela, ValorCaracter);
                if (Registro == null)
                {
                    Registro = Tabela.NewRow();
                    Incluir = true;
                }

                for (int i = 0; i < InclusaoMatriz.Length; i++)
                {
                    if (Registro[i].ToString() != InclusaoMatriz[i].ToString())
                    {
                        Registro[i] = InclusaoMatriz[i];

                        if (Incluir == false)
                            Alterado = true;
                    }
                }

                string[] RegistroLeitura = null;

                if (String.IsNullOrEmpty(Registro[ColunaValor].ToString()) == true)
                    RegistroLeitura = new string[ValorMatriz.Length];
                else
                    RegistroLeitura = (string[])Registro[ColunaValor];

                if (RegistroLeitura.Length == ValorMatriz.Length)
                {
                    for (int ii = 0; ii < RegistroLeitura.Length; ii++)
                    {
                        Registro[ColunaValor] = ValorMatriz;

                        if (Incluir == false)
                            Alterado = true;
                    }
                }
                else
                    Registro[ColunaValor] = ValorMatriz;

                Cadastrar(Tabela, Registro, Incluir, Alterado);
            }
        }

        public static void Copiar(DataTable TabelaConfigurar, string FormularioFonte, string FormularioDestino)
        {
            DataView Visao = TabelaConfigurar.DefaultView;
            Visao.RowFilter = ComandoFiltrar(TabelaConfigurar, "Tipo", FormularioFonte);

            for (int i = 0; i < Visao.Count; i++)
                CadastrarMatriz(TabelaConfigurar, String.Concat(FormularioDestino, "|", Visao[i]["Parametro"].ToString(), "|", ValorUnico(TabelaConfigurar, String.Concat(Visao[i]["Tipo"].ToString(), "|", Visao[i]["Parametro"].ToString()), "Valor")));
        }

        public static void Excluir(DataTable Tabela, string ValorCaracter)
        {
            DataRow Registro = Posicionar(Tabela, ValorCaracter);
            if (Registro != null)
                Registro.Delete();
        }

        public static void Limpar(DataTable Tabela, string Campo, string Pesquisa)
        {
            string Registros;

            try
            {
                foreach (DataRow Linha in Tabela.Rows)
                {
                    if (Linha[Campo].ToString().Trim().ToUpper() == Pesquisa.Trim().ToUpper())
                    {
                        Registros = "";

                        for (int i = 0; i < Tabela.PrimaryKey.Length; i++)
                        {
                            Registros = String.Concat(Registros, Linha[Tabela.Columns[i].ColumnName].ToString());
                            if (i < Tabela.PrimaryKey.Length - 1)
                                Registros = String.Concat(Registros, "|");
                        }

                        Excluir(Tabela, Registros);
                    }
                }
            }
            catch
            {
            }
        }

        public static string ColunaValorUnico(DataRow Posicao, string Coluna)
        {
            string Retorno = "";

            try
            {
                string[] Valor = (string[])Posicao[Coluna];
                Retorno = Valor[0];
            }
            catch
            {
                try
                {
                    string Valor = (string)Posicao[Coluna];
                    Retorno = Valor;
                }
                catch
                {
                    string Valor = Convert.ToString(Posicao[Coluna]);
                    Retorno = Valor;
                }
            }

            return Retorno;
        }

        public static string[] ColunaValorMatriz(DataRow Posicao, string Coluna)
        {
            string[] Retorno = null;

            Retorno = (string[])Posicao[Coluna];

            return Retorno;
        }

        public static string ValorUnico(DataTable Tabela, string Pesquisa, string Coluna)
        {
            string Retorno = "";

            DataRow Posicao = Posicionar(Tabela, Pesquisa);
            if (Posicao != null)
                Retorno = ColunaValorUnico(Posicao, Coluna);

            return Retorno;
        }

        public static string[] ValorMatriz(DataTable Tabela, string Pesquisa, string Coluna)
        {
            string[] Retorno = null;

            DataRow Posicao = Posicionar(Tabela, Pesquisa);
            if (Posicao != null)
                Retorno = ColunaValorMatriz(Posicao, Coluna);

            return Retorno;
        }

        public static bool Encontrado(DataTable Tabela, string Pesquisa)
        {
            bool Retorno = false;

            if (Posicionar(Tabela, Pesquisa) != null)
                Retorno = true;

            return Retorno;
        }

        public static bool Preenchido(DataTable Tabela, string Pesquisa, string Coluna)
        {
            bool Retorno = false;

            if (String.IsNullOrEmpty(ValorUnico(Tabela, Pesquisa, Coluna)) == false)
                Retorno = true;

            return Retorno;
        }
    }
}