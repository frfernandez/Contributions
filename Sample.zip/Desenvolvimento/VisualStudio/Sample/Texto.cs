﻿using System;
using System.Windows.Forms;

namespace Sample
{
    public partial class TextoF : Form
    {
        public string[] Texto;

        public TextoF()
        {
            InitializeComponent();
        }

        private void TextoF_Shown(object sender, EventArgs e)
        {
            for (int i = 0; i < Texto.Length; i++)
            {
                if (i == 0)
                    RcBTexto.Text = String.Concat(RcBTexto.Text, Texto[i]);
                else
                    RcBTexto.Text = String.Concat(RcBTexto.Text, "\n", Texto[i]);
            }
        }

        private void BtnSaida_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}