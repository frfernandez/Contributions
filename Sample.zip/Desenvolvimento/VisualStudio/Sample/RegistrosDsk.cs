﻿/*
 * Português Brasileiro/Español/English
 * Desenvolvedor/Desarrollador/Developer: Fernando Roberto Fernández
 * Projeto/Proyecto/Project: Sample
 * Idioma/Idioma/Idiom: Português Brasileiro/Portugués Brasileño/Brazilian Portuguese
 * 
 * Português Brasileiro
 * Esse arquivo-fonte apresenta um exemplo de como executar os procedimentos armazenados que alimentam as tabelas de controle de permissões.
 * Na propriedade Nodes do componente TrVItensMenusTabelas do formulário ItensMenuTabelasF estão exemplos de como devem ser representados os itens de menu,
 * suas tabelas e as permissões, onde:
 * Primeiro Nó: Nome e descrição do item de menu;
 * Segundo Nó: Nome e descrição da tabela.
 * 
 * A propriedade Tag é utilizada para informar o tipo de permissão.
 * 
 * Español
 * Ese archivo-fuente presenta un ejemplo de como ejecutar los procedimientos almacenados que alimentan las tablas del control de permisiones.
 * En la propiedad Nodes del componente TrVItensMenusTabelas del formulário ItensMenuTabelasF estan ejemplos de como deben ser representados las opciones de menú,
 * sus tablas y las permisiones, donde:
 * Primer nudo: Nombre y descripción del opción de menú;
 * Segun nudo: Nombre y descripción de la tabla.
 * 
 * La propiedad Tag es utilizada para informar el tipo de la permisión.
 * 
 * English
 * This source code show a sample how to execute the stored procedures that feed all tables in the permission control.
 * In the Nodes property of TrVItensMenusTabelas component in the ItensMenuTabelasF form exists examples how to represent the menu itens,
 * your tables and the permissions, where:
 * First node: Menu iten name and description;
 * Second node: Table name and description.
 * 
 * The Tag property is used to inform the kind of permission.
 */

using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace Sample
{
    public sealed class RegistrosDsk : IDisposable
    {
        #region Propriedades Internas

        private BancoDados _BancoDados;
        private ControlesDsk _ControlesDsk;
        private IAECDsk _IAECDsk;
        private PublicosDsk _PublicosDsk;

        #endregion

        #region Propriedades Externas

        public BancoDados BancoDados
        {
            get
            {
                return _BancoDados;
            }
            set
            {
                _BancoDados = value;
            }
        }

        public ControlesDsk ControlesDsk
        {
            get
            {
                return _ControlesDsk;
            }
            set
            {
                _ControlesDsk = value;
            }
        }

        public IAECDsk IAECDsk
        {
            get
            {
                return _IAECDsk;
            }
            set
            {
                _IAECDsk = value;
            }
        }

        public PublicosDsk PublicosDsk
        {
            get
            {
                return _PublicosDsk;
            }
            set
            {
                _PublicosDsk = value;
            }
        }

        #endregion

        public string[] TabelasItensMenu(StreamWriter CaixaPretaArquivo, TreeView ItensMenusTabelas, ProgressBar Medidor)
        {
            string[] Retorno = new string[0],
                     MatrizCodigoItem = new string[0],
                     MatrizMestreDetalhe = new string[0],
                     MatrizNomeRotulo = new string[0];
            string CodigoTabela, NomeTabela, MestreDetalhe, NomeRotulo,
                   CampoCodigo = "", CampoDescricao = "", ItemNomeRotulo = "",
                   ItemNomeDetalhe = "", Papel = "";
            bool Encontrado, Lendo;
            int MatrizAjuste, CodigoItemNomeMestre, CodigoItemNomeDetalhe,
                CodigoItemNomeRelacionado, CodigoPapel;

            Medidor.Minimum = 0;
            Medidor.Maximum = Medidor.Minimum;
            Medidor.Value = Medidor.Minimum;

            Medidor.Maximum = Medidor.Maximum + 1;
            foreach (TreeNode Item in ItensMenusTabelas.Nodes)
            {
                Medidor.Maximum = Medidor.Maximum + 1;

                for (int i = 0; i < Item.Tag.ToString().Trim().Length; i++)
                {
                    Medidor.Maximum = Medidor.Maximum + 1;

                    foreach (TreeNode Tabela in Item.Nodes)
                        Medidor.Maximum = Medidor.Maximum + 1;
                }
            }

            /*
             * Os procedimentos armazenados abaixo serão utilizados:
             * Los procedimientos almacenados abajo seran utilizados:
             * The stored procedures below are used:
             * IncMenu, IncTabelasMenu, IncPapeisMenu
             */

            foreach (TreeNode Item in ItensMenusTabelas.Nodes)
            {
                ToolStripItem[] ItemPrincipalEncontrado = ControlesDsk.MenuPrincipal.Items.Find(String.Concat(Item.Name, "1"), true),
                                ItemDireitoEncontrado = ControlesDsk.MenuBotaoDireito.Items.Find(String.Concat(Item.Name, "2"), true);

                if ((ItemPrincipalEncontrado.Length == 0) ||
                    (ItemDireitoEncontrado.Length == 0))
                {
                    MatrizAjuste = 0;
                    if ((ItemPrincipalEncontrado.Length == 0) &&
                        (ItemDireitoEncontrado.Length == 0))
                        MatrizAjuste = 1;

                    Array.Resize(ref Retorno, Retorno.Length + (6 + MatrizAjuste));

                    Retorno[Retorno.Length - (6 + MatrizAjuste)] = "*******************************";
                    Retorno[Retorno.Length - (5 + MatrizAjuste)] = "* Item de Menu Não Encontrado *";
                    Retorno[Retorno.Length - (4 + MatrizAjuste)] = "*******************************";

                    if (ItemPrincipalEncontrado.Length == 0)
                    {
                        Retorno[Retorno.Length - (3 + MatrizAjuste)] = String.Concat("Nome do Menu Mestre.: ", Item.Name, "1");
                        Retorno[Retorno.Length - (2 + MatrizAjuste)] = String.Concat("Item do Menu Mestre.: ", Item.Text.Trim());
                    }

                    if (ItemDireitoEncontrado.Length == 0)
                    {
                        Retorno[Retorno.Length - 3] = String.Concat("Nome do Menu Detalhe: ", Item.Name, "2");
                        Retorno[Retorno.Length - 2] = String.Concat("Item do Menu Detalhe: ", Item.Text.Trim());
                    }

                    Retorno[Retorno.Length - 1] = "";
                }
                else
                {
                    for (int i = 0; i < Item.Tag.ToString().Trim().Length; i++)
                    {
                        /*
                         * Para que esta parte funcione corretamente deve ser criador um método que retire os acentos das palavras...
                         * Para que este punto trabaje correctamente debe ser creado un método que saque las crases de las palabras...
                         * For this point run correctly should be created a method to take off the crasis of the words...
                         * 
                         * Procedimentos/Procedimientos/Procedure: IncMenu
                         * Paramêtros/Parámentros/Parameters
                         * Operacao         = Caracteres.RemoveAcentos(Item.Tag.ToString().Trim().Substring(i, 1));
                         * ItemNomeMestre   = Caracteres.RemoveAcentos(Item.Name.Trim().ToUpper());
                         * ItemRotuloMestre = Caracteres.RemoveAcentos(Item.Text.Trim().ToUpper());
                         */

                        if ((Item.Tag.ToString().Substring(i, 1).Trim().ToUpper() == "I") ||
                            (Item.Tag.ToString().Substring(i, 1).Trim().ToUpper() == "A") ||
                            (Item.Tag.ToString().Substring(i, 1).Trim().ToUpper() == "E"))
                            ItemNomeDetalhe = Caracteres.RemoveAcentos(String.Concat(Item.Name.Trim().ToUpper(), TarefaDescricao(Item.Tag.ToString().Substring(i, 1), false)).Trim().ToUpper());
                        else
                            ItemNomeDetalhe = Caracteres.RemoveAcentos(Item.Name.Trim().ToUpper());

                        /*
                         * Procedimentos/Procedimientos/Procedure: ItemNomeDetalhe
                         * Paramêtros/Parámentros/Parameters
                         * ItemNomeDetalhe   = ItemNomeDetalhe;
                         * ItemRotuloDetalhe = Caracteres.RemoveAcentos(String.Concat(Item.Text.Trim().ToUpper(), " - ", TarefaDescricao(Item.Tag.ToString().Substring(i, 1), false)).Trim().ToUpper());
                         */

                        /*
                         * Procedimentos/Procedimientos/Procedure: IncMenu
                         * .ExecuteNonQuery();
                         */

                        CodigoItemNomeMestre = Convert.ToInt32(this.TabelaConsulta("MenusMestresNomes", "ItemNome", "Codigo", "T", Caracteres.RemoveAcentos(Item.Name.Trim().ToUpper())));
                        CodigoItemNomeDetalhe = Convert.ToInt32(this.TabelaConsulta("MenusDetalhesNomes", "ItemNome", "Codigo", "T", ItemNomeDetalhe));

                        if (i == 0)
                        {
                            /*
                             * Procedimentos/Procedimientos/Procedure: ExcMenusRelacionados
                             * Paramêtros/Parámentros/Parameters
                             * CodigoItemPrincipal = CodigoItemNomeMestre.ToString();
                             * .ExecuteNonQuery();
                             * .Dispose();
                             */
                        }

                        Papel = String.Concat("RL_",
                                              Caracteres.RemoveAcentos(TarefaDescricao(Item.Tag.ToString().Substring(i, 1), true).Trim().ToUpper()),
                                              "_",
                                              Caracteres.RemoveAcentos(Item.Name.Trim().Substring(ItemMenuDescricao(Item.Tag.ToString(), false).Length)));
                        Papel = Papel.ToUpper();

                        if (Item.Nodes.Count == 0)
                            PapeisExcluir(Papel);
                        else
                        {
                            if (PapeisAdministrar(Papel) == true)
                            {
                                CodigoPapel = Convert.ToInt32(this.TabelaConsulta("Papeis", "Papel", "Codigo", "T", Papel));

                                /*
                                 * Procedimentos/Procedimientos/Procedure: IncPapeisMenu
                                 * Paramêtros/Parámentros/Parameters
                                 * CodigoItemMestre  = CodigoItemNomeMestre.ToString();
                                 * CodigoItemDetalhe = CodigoItemNomeDetalhe.ToString();
                                 * CodigoPapel       = CodigoPapel.ToString();
                                 * .ExecuteNonQuery();
                                 */
                            }
                            else
                            {
                                Array.Resize(ref Retorno, Retorno.Length + 6);

                                Retorno[Retorno.Length - 6] = "********************";
                                Retorno[Retorno.Length - 5] = "* Papel Não Criado *";
                                Retorno[Retorno.Length - 4] = "********************";
                                Retorno[Retorno.Length - 3] = "";
                                Retorno[Retorno.Length - 2] = String.Concat("Papel...............: ", Papel);
                                Retorno[Retorno.Length - 1] = "";
                            }
                        }

                        foreach (TreeNode Tabela in Item.Nodes)
                        {
                            if ((Tabela.Tag != null) && (Caracteres.RemoveAcentos(Tabela.Tag.ToString().Trim().ToUpper()) == "MN"))
                            {
                                CodigoItemNomeRelacionado = Convert.ToInt32(this.TabelaConsulta("MenusMestresNomes", "ItemNome", "Codigo", "T", Caracteres.RemoveAcentos(Tabela.Name.Trim().ToUpper())));

                                /*
                                 * Procedimentos/Procedimientos/Procedure: IncMenusRelacionados
                                 * Paramêtros/Parámentros/Parameters
                                 * CodigoItemPrincipal   = CodigoItemNomeMestre.ToString();
                                 * CodigoItemRelacionado = CodigoItemNomeRelacionado.ToString();
                                 * .ExecuteNonQuery();
                                 * .Dispose();
                                 */
                            }
                            else
                            {
                                NomeTabela = Tabela.Name.Trim().ToUpper();
                                CodigoTabela = this.TabelaConsulta("Tabelas", "Tabela", "Codigo", "T", NomeTabela);
                                if (string.IsNullOrEmpty(CodigoTabela) == true)
                                {
                                    Array.Resize(ref Retorno, Retorno.Length + 8);
                                    Retorno[Retorno.Length - 8] = "*************************";
                                    Retorno[Retorno.Length - 7] = "* Tabela Não Encontrada *";
                                    Retorno[Retorno.Length - 6] = "*************************";
                                    Retorno[Retorno.Length - 5] = "";
                                    Retorno[Retorno.Length - 4] = String.Concat("Tabela..............: ", Tabela.Name.Trim());
                                    Retorno[Retorno.Length - 3] = String.Concat("Item de Menu Mestre.: ", Item.Text.Trim());
                                    Retorno[Retorno.Length - 2] = String.Concat("Item de Menu Detalhe: ", Item.Text.Trim(), " - ", TarefaDescricao(Item.Tag.ToString().Substring(i, 1), false).Trim());
                                    Retorno[Retorno.Length - 1] = "";
                                }
                                else
                                {
                                    if (this.TabelaPosicao("TabelasMenuTabelaMenu", "CodigoTabela", "P", CodigoTabela) == -1)
                                        /*
                                         * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
                                         * .CommandText = "IncTabelasMenu";
                                         */
                                        ;
                                    else
                                        /*
                                         * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
                                         * .CommandText = "AltTabelasMenu";
                                         */
                                        ;

                                    /*
                                     * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
                                     * Paramêtros/Parámentros/Parameters
                                     * CodigoItemMestre  = CodigoItemNomeMestre.ToString();
                                     * CodigoItemDetalhe = CodigoItemNomeDetalhe.ToString();
                                     * CodigoTabela      = CodigoTabela.ToString();
                                     * .ExecuteNonQuery();
                                     * .Dispose();
                                     */

                                    if (Tabela.Tag == null)
                                        /*
                                         * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
                                         * Permissao = Permissao(Item.Tag.ToString().Substring(i, 1));
                                         */
                                        ;
                                    else
                                        /*
                                         * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
                                         * Permissao = Permissao(Tabela.Tag.ToString());
                                         */
                                        ;

                                    /*
                                     * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
                                     * .ExecuteNonQuery();
                                     */
                                }
                            }

                            Medidor.Value = Medidor.Value + 1;
                        }

                        Medidor.Value = Medidor.Value + 1;
                    }
                }

                Medidor.Value = Medidor.Value + 1;
            }

            /*
             * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
             * Paramêtros/Parámentros/Parameters
             * CodigoItemMestre  = CodigoItemNomeMestre.ToString();
             * CodigoItemDetalhe = CodigoItemNomeDetalhe.ToString();
             * CodigoTabela      = CodigoTabela.ToString();
             * .ExecuteNonQuery();
             * .Dispose();
             */

            /*
             * Procedimentos/Procedimientos/Procedure: IncMenu
             * .Dispose();
             */

            /*
             * Procedimentos/Procedimientos/Procedure: IncPapeisMenu
             * .Dispose();
             */

            /*
             * Procedimentos/Procedimientos/Procedure: SelecaoMenu
             * IDataReader Leitor = <IDataReader>;
             */

            //if (Leitor.Read() == true)
            {
                Lendo = true;
                while (Lendo == true)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        Encontrado = false;

                        if (i == 0)
                        {
                            CampoCodigo = "CodigoItemNomeMestre";
                            CampoDescricao = "ItemNomeMestre";
                        }
                        else if (i == 1)
                        {
                            CampoCodigo = "CodigoItemRotuloMestre";
                            CampoDescricao = "ItemRotuloMestre";
                        }
                        else if (i == 2)
                        {
                            CampoCodigo = "CodigoItemNomeDetalhe";
                            CampoDescricao = "ItemNomeDetalhe";
                        }
                        else if (i == 3)
                        {
                            CampoCodigo = "CodigoItemRotuloDetalhe";
                            CampoDescricao = "ItemRotuloDetalhe";
                        }

                        if (i <= 1)
                            MestreDetalhe = "M";
                        else
                            MestreDetalhe = "D";

                        if ((i == 0) ||
                            (i == 2))
                            NomeRotulo = "N";
                        else
                            NomeRotulo = "R";

                        foreach (TreeNode Item in ItensMenusTabelas.Nodes)
                        {
                            if (i <= 1)
                            {
                                if (i == 0)
                                    ItemNomeRotulo = Caracteres.RemoveAcentos(Item.Name.Trim().ToUpper());
                                else if (i == 1)
                                    ItemNomeRotulo = Caracteres.RemoveAcentos(Item.Text.Trim().ToUpper());

                                if (ItemNomeRotulo == Leitor[CampoDescricao].ToString())
                                    Encontrado = true;
                            }
                            else
                            {
                                for (int ii = 0; ii < Item.Tag.ToString().Trim().Length; ii++)
                                {
                                    if (i == 2)
                                        ItemNomeRotulo = Caracteres.RemoveAcentos(String.Concat(Item.Name.Trim().ToUpper(), TarefaDescricao(Item.Tag.ToString().Substring(ii, 1), false)).Trim().ToUpper());
                                    else if (i == 3)
                                        ItemNomeRotulo = Caracteres.RemoveAcentos(String.Concat(Item.Text.Trim().ToUpper(), " - ", TarefaDescricao(Item.Tag.ToString().Substring(ii, 1), false)).Trim().ToUpper());

                                    if (ItemNomeRotulo == Leitor[CampoDescricao].ToString())
                                    {
                                        Encontrado = true;
                                        break;
                                    }
                                }
                            }

                            if (Encontrado == true)
                                break;
                        }

                        if ((i == 3) &&
                            (Encontrado == false))
                        {
                            Array.Resize(ref MatrizCodigoItem, MatrizCodigoItem.Length + 1);
                            MatrizCodigoItem[MatrizCodigoItem.Length - 1] = Leitor[CampoCodigo].ToString();

                            Array.Resize(ref MatrizMestreDetalhe, MatrizMestreDetalhe.Length + 1);
                            MatrizMestreDetalhe[MatrizMestreDetalhe.Length - 1] = MestreDetalhe;

                            Array.Resize(ref MatrizNomeRotulo, MatrizNomeRotulo.Length + 1);
                            MatrizNomeRotulo[MatrizNomeRotulo.Length - 1] = NomeRotulo;
                        }
                    }

                    //Lendo = Leitor.Read();
                }
            }
            /*
             * Leitor.Close();
             * Leitor.Dispose();
             */

            /*
             * Procedimentos/Procedimientos/Procedure: IncTabelasMenu
             * .Dispose();
             */

            /*
             * Procedimentos/Procedimientos/Procedure: IncMenu
             * .Dispose();
             */

            for (int i = 0; i < MatrizCodigoItem.Length; i++)
            {
                /*
                 * Procedimentos/Procedimientos/Procedure: ExcMenu
                 * Paramêtros/Parámentros/Parameters
                 * CodigoItem    = MatrizCodigoItem[i];
                 * MestreDetalhe = MatrizMestreDetalhe[i];
                 * NomeRotulo    = MatrizNomeRotulo[i];
                 * .ExecuteNonQuery();
                 * .Dispose();
                 */
            }

            Medidor.Value = Medidor.Value + 1;

            return Retorno;
        }

        private string Permissao(string Valor)
        {
            string Retorno;

            if ((Valor == "IC") ||
                (Valor == "AC") ||
                (Valor == "EC"))
                Retorno = String.Concat(Valor.Substring(0, 1), "S");
            else
            {
                if ((Valor != "I") &&
                    (Valor != "A") &&
                    (Valor != "E") &&
                    (Valor != "IA") &&
                    (Valor != "IE") &&
                    (Valor != "AE") &&
                    (Valor != "IAE") &&
                    (Valor != "T"))
                    Retorno = "S";
                else
                    Retorno = Valor;
            }

            return Retorno;
        }

        private string TarefaDescricao(string Operacao, bool Abreviar)
        {
            string Retorno = "";

            if (Abreviar == true)
            {
                if (Operacao == "I")
                    Retorno = "Inc";
                else if (Operacao == "A")
                    Retorno = "Alt";
                else if (Operacao == "E")
                    Retorno = "Exc";
                else if (Operacao == "C")
                    Retorno = "Cns";
                else if (Operacao == "R")
                    Retorno = "Rel";
                else if (Operacao == "U")
                    Retorno = "Uti";
                else if (Operacao == "X")
                    Retorno = "Cnx";
            }
            else
            {
                if (Operacao == "I")
                    Retorno = "Inclusão";
                else if (Operacao == "A")
                    Retorno = "Alteração";
                else if (Operacao == "E")
                    Retorno = "Exclusão";
                else if (Operacao == "C")
                    Retorno = "Consulta";
                else if (Operacao == "R")
                    Retorno = "Relatório";
                else if (Operacao == "U")
                    Retorno = "Utilitários";
                else if (Operacao == "X")
                    Retorno = "Conexão";
            }

            return Retorno;
        }

        private string ItemMenuDescricao(string Operacao, bool Abreviar)
        {
            string Retorno = "";

            if (Abreviar == true)
            {
                if ((Operacao == "I") ||
                    (Operacao == "A") ||
                    (Operacao == "E") ||
                    (Operacao == "IA") ||
                    (Operacao == "IE") ||
                    (Operacao == "AE") ||
                    (Operacao == "IAE"))
                    Retorno = "Cad";
                else if (Operacao == "C")
                    Retorno = "Cns";
                else if (Operacao == "R")
                    Retorno = "Rel";
                else if (Operacao == "U")
                    Retorno = "Uti";
                else if (Operacao == "X")
                    Retorno = "Cnx";
            }
            else
            {
                if ((Operacao == "I") ||
                    (Operacao == "A") ||
                    (Operacao == "E") ||
                    (Operacao == "IA") ||
                    (Operacao == "IE") ||
                    (Operacao == "AE") ||
                    (Operacao == "IAE"))
                    Retorno = "Cadastros";
                else if (Operacao == "C")
                    Retorno = "Consultas";
                else if (Operacao == "R")
                    Retorno = "Relatórios";
                else if (Operacao == "U")
                    Retorno = "Utilitários";
                else if (Operacao == "X")
                    Retorno = "Conexão";
            }

            return Retorno;
        }

        public bool PapeisExcluir(string Papel)
        {
            bool Retorno = true;

            try
            {
                string Codigo = this.TabelaConsulta("Papeis", "Papel", "Codigo", "T", Papel.Trim());
                if (String.IsNullOrEmpty(Codigo) == false)
                {
                    /*
                     * Procedimentos/Procedimientos/Procedure: ExcPapeis
                     * Paramêtros/Parámentros/Parameters
                     * Codigo = Codigo;
                     * .Dispose();
                     */
                }
            }
            catch (Exception Excecao)
            {
                MessageBox.Show(String.Concat("Erro ao tentar excluir o papel ", Papel.Trim(), " utilizando o procedimento ExclusaoPapeis no banco de dados."));

                Retorno = false;
            }

            return Retorno;
        }

        private bool PapeisAdministrar(string Papel)
        {
            bool Retorno = true;
            string Comando = "";

            if (String.IsNullOrEmpty(Papel) == true)
                Comando = "Drop ";
            else
                Comando = "Create ";

            Comando = String.Concat(Comando, "Role");

            try
            {
                if (String.IsNullOrEmpty(Papel) == true)
                {
                    /*
                     * Procedimentos/Procedimientos/Procedure: PapelExcluir
                     * Paramêtros/Parámentros/Parameters
                     * Codigo = Codigo;
                     * .Dispose();
                     */

                    /*
                     * IDataReader Leitor = <IDataReader>;
                     * DataTable Tabela = <DataTable>;
                     */

                    //foreach (var Linha in Tabela.AsEnumerable())
                    {
                        /*
                         * IDbCommand ComandoObjeto = <IDbCommand>;
                         * Executar/Ejecutar/Execute
                         * String.Concat(Comando, " ", Linha[0].ToString());
                         * .ExecuteNonQuery();
                         * .Dispose();
                         */
                    }

                    /*
                     * Procedimentos/Procedimientos/Procedure: PapelExcluir
                     * .Dispose();
                     */

                    /*
                     * Tabela.Dispose();
                     * Leitor.Close();
                     * Leitor.Dispose();
                     * 
                     * Procedimentos/Procedimientos/Procedure: PapelExcluir
                     * .Dispose();
                     */
                }
                else
                {
                    /*
                     * Procedimentos/Procedimientos/Procedure: PapelExiste
                     * Paramêtros/Parámentros/Parameters
                     * Papel = Papel.Trim();
                     */

                    /*
                     * IDataReader Leitor = <IDataReader>;
                     * .Read();
                     * string Existe = Leitor[0].ToString();
                     * .Close();
                     * .Dispose();
                     */

                    //if (Existe == "N")
                    {
                        /*
                         * IDbCommand ComandoObjeto = <IDbCommand>;
                         * Executar/Ejecutar/Execute
                         * String.Concat(Comando, " ", Papel.Trim());
                         * .ExecuteNonQuery();
                         * .Dispose();
                         */
                    }

                    /*
                     * Procedimentos/Procedimientos/Procedure: PapelExiste
                     * .Dispose();
                     */
                }
            }
            catch (Exception Excecao)
            {
                MessageBox.Show(String.Concat("Erro ao tentar executar o comando ", Comando, "."));

                Retorno = false;
            }

            return Retorno;
        }

        public int TabelaPosicao(string TabelaProcedimento, string ColunaConsulta, string Tipo, string ValorConsulta)
        {
            int Retorno;

            BindingSource Amarrador = TabelaAmarrador(TabelaProcedimento, "", ColunaConsulta, Tipo);
            Retorno = Amarrador.Find(ColunaConsulta, ValorConsulta);
            Amarrador.Dispose();

            return Retorno;
        }

        public string TabelaConsulta(string TabelaProcedimento, string ColunaConsulta, string ColunaRetorno, string Tipo, string ValorConsulta)
        {
            string Retorno = null;

            BindingSource Amarrador = TabelaAmarrador(TabelaProcedimento, ColunaRetorno, ColunaConsulta, Tipo);
            //((DataView)Amarrador.DataSource).RowFilter = ColunaConsulta, ValorConsulta;

            if (Amarrador.Count > 0)
                //Retorno = ColunaRetorno
                ;

            Amarrador.Dispose();

            return Retorno;
        }

        private BindingSource TabelaAmarrador(string TabelaProcedimento, string ColunaCodigo, string ColunaDescricao, string Tipo)
        {
            BindingSource Retorno = new BindingSource();
            string TabelaProcedimentoAtual = "",
                   ColunaCodigoAtual = TabelaMemoriaNeutro.ValorUnico(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|ColunaCodigo"), "Valor"),
                   ColunaDescricaoAtual = TabelaMemoriaNeutro.ValorUnico(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|ColunaDescricao"), "Valor");

            TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|ColunaCodigo|", ColunaCodigo));
            TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|ColunaDescricao|", ColunaDescricao));

            DataTable TabelaRegistros = new DataTable();

            if (Tipo == "P")
            {
                TabelaProcedimentoAtual = TabelaMemoriaNeutro.ValorUnico(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|Procedimento"), "Valor");

                TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|Procedimento|", TabelaProcedimento));

                TabelaRegistros = BancoDados.TabelaProcedimento(0);
            }
            else if (Tipo == "T")
            {
                TabelaProcedimentoAtual = TabelaMemoriaNeutro.ValorUnico(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|TabelaComDescricao"), "Valor");

                TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|TabelaComDescricao|", TabelaProcedimento));

                TabelaRegistros = BancoDados.TabelaDados();
            }

            DataView Visao = TabelaRegistros.DefaultView;

            if (ColunaDescricao.IndexOf(";") == -1)
                Visao.Sort = ColunaDescricao;

            Retorno.DataSource = Visao;

            if (Tipo == "P")
                TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|Procedimento|", TabelaProcedimentoAtual));
            else if (Tipo == "T")
                TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|TabelaComDescricao|", TabelaProcedimentoAtual));

            TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|ColunaCodigo|", ColunaCodigoAtual));
            TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|ColunaDescricao|", ColunaDescricaoAtual));

            return Retorno;
        }

        private void ProcedimentosParametros(ListBox CaixaListagem)
        {
            if (BancoDados.TabelaComponentes == null)
            {
                BancoDados.TabelaComponentes = new DataTable("Componentes");

                DataColumn Formulario = new DataColumn("Formulario", typeof(string));
                Formulario.MaxLength = 255;
                Formulario.AllowDBNull = false;
                Formulario.Caption = "Formulário";

                DataColumn Nome = new DataColumn("Nome", typeof(string));
                Nome.MaxLength = 50;
                Nome.AllowDBNull = false;
                Nome.Caption = "Nome";

                DataColumn EntradaSaida = new DataColumn("EntradaSaida", typeof(string));
                EntradaSaida.MaxLength = 1;
                EntradaSaida.AllowDBNull = false;
                EntradaSaida.Caption = "Entrada / Saída";

                DataColumn LarguraCampo = new DataColumn("LarguraCampo", typeof(int));
                LarguraCampo.AllowDBNull = true;
                LarguraCampo.Caption = "Largura Campo";

                DataColumn Precisao = new DataColumn("Precisao", typeof(int));
                Precisao.AllowDBNull = true;
                Precisao.Caption = "Precisão";

                DataColumn Escala = new DataColumn("Escala", typeof(int));
                Escala.AllowDBNull = true;
                Escala.Caption = "Escala";

                DataColumn CodigoTipo = new DataColumn("CodigoTipo", typeof(int));
                CodigoTipo.AllowDBNull = true;
                CodigoTipo.Caption = "Código Tipo";

                DataColumn CodigoSubTipo = new DataColumn("CodigoSubTipo", typeof(int));
                CodigoSubTipo.AllowDBNull = true;
                CodigoSubTipo.Caption = "Código Sub Tipo";

                DataColumn LarguraCaracter = new DataColumn("LarguraCaracter", typeof(int));
                LarguraCaracter.AllowDBNull = true;
                LarguraCaracter.Caption = "Largura Caracter";

                DataColumn Tipo = new DataColumn("Tipo", typeof(string));
                Tipo.MaxLength = 50;
                Tipo.AllowDBNull = false;
                Tipo.Caption = "Tipo";

                DataColumn SubTipo = new DataColumn("SubTipo", typeof(string));
                SubTipo.MaxLength = 50;
                SubTipo.AllowDBNull = true;
                SubTipo.Caption = "Sub Tipo";

                BancoDados.TabelaComponentes.Columns.Add(Formulario);
                BancoDados.TabelaComponentes.Columns.Add(Nome);
                BancoDados.TabelaComponentes.Columns.Add(EntradaSaida);
                BancoDados.TabelaComponentes.Columns.Add(LarguraCampo);
                BancoDados.TabelaComponentes.Columns.Add(Precisao);
                BancoDados.TabelaComponentes.Columns.Add(Escala);
                BancoDados.TabelaComponentes.Columns.Add(CodigoTipo);
                BancoDados.TabelaComponentes.Columns.Add(CodigoSubTipo);
                BancoDados.TabelaComponentes.Columns.Add(LarguraCaracter);
                BancoDados.TabelaComponentes.Columns.Add(Tipo);
                BancoDados.TabelaComponentes.Columns.Add(SubTipo);

                BancoDados.TabelaComponentes = TabelaMemoriaNeutro.ChavePrimaria(BancoDados.TabelaComponentes, "Formulario;Nome");
            }

            if (TabelaMemoriaNeutro.Encontrado(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|Procedimento")) == false)
            {
                string[] Cadastro = { "I", "A", "E" },
                         Procedimentos = { };
                DataTable Tabela;

                TabelaMemoriaNeutro.CadastrarMatriz(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|Procedimento|ProcedimentosParametros"));

                for (int i = 0; i < Cadastro.Length; i++)
                {
                    if (TabelaMemoriaNeutro.Encontrado(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|", Cadastro[i])) == true)
                    {
                        Array.Resize(ref Procedimentos, Procedimentos.Length + 1);
                        Procedimentos[Procedimentos.Length - 1] = TabelaMemoriaNeutro.ValorUnico(BancoDados.TabelaConfigurar, String.Concat(BancoDados.FormularioNome, "|", Cadastro[i]), "Valor");
                    }
                }

                if (CaixaListagem != null)
                {
                    for (int i = 0; i < CaixaListagem.Items.Count; i++)
                    {
                        if (String.IsNullOrEmpty(CaixaListagem.Items[i].ToString()) == false)
                        {
                            Array.Resize(ref Procedimentos, Procedimentos.Length + 1);
                            Procedimentos[Procedimentos.Length - 1] = CaixaListagem.Items[i].ToString();
                        }
                    }
                }

                for (int i = 0; i < Procedimentos.Length; i++)
                {
                    BancoDados.TextoConsulta = Procedimentos[i];
                    Tabela = BancoDados.TabelaProcedimento(0);
                    foreach (DataRow Linha in Tabela.Rows)
                    {
                        if (TabelaMemoriaNeutro.Encontrado(BancoDados.TabelaComponentes, String.Concat(BancoDados.FormularioNome, "|", Linha["Nome"].ToString().ToUpper())) == false)
                        {
                            DataRow Registro = BancoDados.TabelaComponentes.NewRow();
                            Registro["Formulario"] = BancoDados.FormularioNome;

                            foreach (DataColumn Coluna in Tabela.Columns)
                            {
                                if (Coluna.DataType == typeof(string))
                                {
                                    if (String.IsNullOrEmpty(Linha[Coluna.ColumnName].ToString()) == true)
                                        Registro[Coluna.ColumnName] = DBNull.Value;
                                    else
                                        Registro[Coluna.ColumnName] = Linha[Coluna.ColumnName].ToString().ToUpper();
                                }
                                else
                                    Registro[Coluna.ColumnName] = Linha[Coluna.ColumnName];
                            }

                            BancoDados.TabelaComponentes.Rows.Add(Registro);
                        }
                    }
                }
            }
        }
    }
}