﻿namespace Sample
{
    partial class MainF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainF));
            this.MenuBotaoDireito = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Cadastros2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosDocumentos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosDocumentosPessoais2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidades2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesTitulos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesEnderecos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesBairros2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesCidades2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesEstados2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesPaises2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesContinentes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosComunicacoes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosComunicacoesTiposTelefones2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosComunicacoesTiposComunicacoes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosContatos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosAgenda2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Consultas2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidades2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidadesCidades2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidadesEstados2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidadesPaises2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasContatos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasAgenda2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Relatorios2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosDocumentos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosDocumentosPessoais2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosLocalidades2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosTitulosEnderecos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosEnderecos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosBairros2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosCidades2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosEstados2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosPaises2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosContinentes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosComunicacoes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosTiposTelefones2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosTiposComunicacoes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosContatos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosAgenda2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.RelatoriosAcessos2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Utilitarios2 = new System.Windows.Forms.ToolStripMenuItem();
            this.UtilitariosImpressora2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.UtilitariosVersao2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.UtilitariosTexto2 = new System.Windows.Forms.ToolStripMenuItem();
            this.UtilitariosPublico2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Conexao2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConexaoConectar2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConexaoConectarComo2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConexaoDesconectar2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.ConexaoConfiguracoes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.ConexaoAtualizarPermissoes2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Saida2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuMain = new System.Windows.Forms.MenuStrip();
            this.Cadastros1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosDocumentos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosDocumentosPessoais1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidades1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesTitulos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesEnderecos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesBairros1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesCidades1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesEstados1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesPaises1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosLocalidadesContinentes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosComunicacoes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosComunicacoesTiposTelefones1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosComunicacoesTiposComunicacoes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosContatos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastrosAgenda1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Consultas1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidades1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidadesCidades1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidadesEstados1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasLocalidadesPaises1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasContatos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConsultasAgenda1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Relatorios1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosDocumentos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosDocumentosPessoais1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosLocalidades1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosTitulosEnderecos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosEnderecos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosBairros1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosCidades1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosEstados1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosPaises1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosContinentes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosComunicacoes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosTiposTelefones1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosTiposComunicacoes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosContatos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RelatoriosAgenda1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.RelatoriosAcessos1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Utilitarios1 = new System.Windows.Forms.ToolStripMenuItem();
            this.UtilitariosImpressora1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.UtilitariosVersao1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.UtilitariosTexto1 = new System.Windows.Forms.ToolStripMenuItem();
            this.UtilitariosPublico1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Conexao1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConexaoConectar1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConexaoConectarComo1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ConexaoDesconectar1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.ConexaoConfiguracoes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.ConexaoAtualizarPermissoes1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Saida1 = new System.Windows.Forms.ToolStripMenuItem();
            this.PcBImagem = new System.Windows.Forms.PictureBox();
            this.MenuBotaoDireito.SuspendLayout();
            this.MenuMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcBImagem)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuBotaoDireito
            // 
            this.MenuBotaoDireito.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Cadastros2,
            this.Consultas2,
            this.Relatorios2,
            this.Utilitarios2,
            this.Conexao2,
            this.Saida2});
            this.MenuBotaoDireito.Name = "MenuBotaoDireito";
            this.MenuBotaoDireito.Size = new System.Drawing.Size(127, 136);
            // 
            // Cadastros2
            // 
            this.Cadastros2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosDocumentos2,
            this.CadastrosLocalidades2,
            this.CadastrosComunicacoes2,
            this.CadastrosContatos2,
            this.CadastrosAgenda2});
            this.Cadastros2.Name = "Cadastros2";
            this.Cadastros2.Size = new System.Drawing.Size(126, 22);
            this.Cadastros2.Text = "Cadastros";
            // 
            // CadastrosDocumentos2
            // 
            this.CadastrosDocumentos2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosDocumentosPessoais2});
            this.CadastrosDocumentos2.Name = "CadastrosDocumentos2";
            this.CadastrosDocumentos2.Size = new System.Drawing.Size(153, 22);
            this.CadastrosDocumentos2.Text = "Documentos";
            // 
            // CadastrosDocumentosPessoais2
            // 
            this.CadastrosDocumentosPessoais2.Name = "CadastrosDocumentosPessoais2";
            this.CadastrosDocumentosPessoais2.Size = new System.Drawing.Size(189, 22);
            this.CadastrosDocumentosPessoais2.Text = "Documentos Pessoais";
            // 
            // CadastrosLocalidades2
            // 
            this.CadastrosLocalidades2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosLocalidadesTitulos2,
            this.CadastrosLocalidadesEnderecos2,
            this.CadastrosLocalidadesBairros2,
            this.CadastrosLocalidadesCidades2,
            this.CadastrosLocalidadesEstados2,
            this.CadastrosLocalidadesPaises2,
            this.CadastrosLocalidadesContinentes2});
            this.CadastrosLocalidades2.Name = "CadastrosLocalidades2";
            this.CadastrosLocalidades2.Size = new System.Drawing.Size(153, 22);
            this.CadastrosLocalidades2.Text = "Localidades";
            // 
            // CadastrosLocalidadesTitulos2
            // 
            this.CadastrosLocalidadesTitulos2.Name = "CadastrosLocalidadesTitulos2";
            this.CadastrosLocalidadesTitulos2.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesTitulos2.Text = "Títulos";
            // 
            // CadastrosLocalidadesEnderecos2
            // 
            this.CadastrosLocalidadesEnderecos2.Name = "CadastrosLocalidadesEnderecos2";
            this.CadastrosLocalidadesEnderecos2.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesEnderecos2.Text = "Endereços";
            // 
            // CadastrosLocalidadesBairros2
            // 
            this.CadastrosLocalidadesBairros2.Name = "CadastrosLocalidadesBairros2";
            this.CadastrosLocalidadesBairros2.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesBairros2.Text = "Bairros";
            // 
            // CadastrosLocalidadesCidades2
            // 
            this.CadastrosLocalidadesCidades2.Name = "CadastrosLocalidadesCidades2";
            this.CadastrosLocalidadesCidades2.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesCidades2.Text = "Cidades";
            // 
            // CadastrosLocalidadesEstados2
            // 
            this.CadastrosLocalidadesEstados2.Name = "CadastrosLocalidadesEstados2";
            this.CadastrosLocalidadesEstados2.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesEstados2.Text = "Estados";
            // 
            // CadastrosLocalidadesPaises2
            // 
            this.CadastrosLocalidadesPaises2.Name = "CadastrosLocalidadesPaises2";
            this.CadastrosLocalidadesPaises2.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesPaises2.Text = "Países";
            // 
            // CadastrosLocalidadesContinentes2
            // 
            this.CadastrosLocalidadesContinentes2.Name = "CadastrosLocalidadesContinentes2";
            this.CadastrosLocalidadesContinentes2.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesContinentes2.Text = "Continentes";
            // 
            // CadastrosComunicacoes2
            // 
            this.CadastrosComunicacoes2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosComunicacoesTiposTelefones2,
            this.CadastrosComunicacoesTiposComunicacoes2});
            this.CadastrosComunicacoes2.Name = "CadastrosComunicacoes2";
            this.CadastrosComunicacoes2.Size = new System.Drawing.Size(153, 22);
            this.CadastrosComunicacoes2.Text = "Comunicações";
            // 
            // CadastrosComunicacoesTiposTelefones2
            // 
            this.CadastrosComunicacoesTiposTelefones2.Name = "CadastrosComunicacoesTiposTelefones2";
            this.CadastrosComunicacoesTiposTelefones2.Size = new System.Drawing.Size(200, 22);
            this.CadastrosComunicacoesTiposTelefones2.Text = "Tipos de Telefones";
            // 
            // CadastrosComunicacoesTiposComunicacoes2
            // 
            this.CadastrosComunicacoesTiposComunicacoes2.Name = "CadastrosComunicacoesTiposComunicacoes2";
            this.CadastrosComunicacoesTiposComunicacoes2.Size = new System.Drawing.Size(200, 22);
            this.CadastrosComunicacoesTiposComunicacoes2.Text = "Tipos de Comunicações";
            // 
            // CadastrosContatos2
            // 
            this.CadastrosContatos2.Name = "CadastrosContatos2";
            this.CadastrosContatos2.Size = new System.Drawing.Size(153, 22);
            this.CadastrosContatos2.Text = "Contatos";
            // 
            // CadastrosAgenda2
            // 
            this.CadastrosAgenda2.Name = "CadastrosAgenda2";
            this.CadastrosAgenda2.Size = new System.Drawing.Size(153, 22);
            this.CadastrosAgenda2.Text = "Agenda";
            // 
            // Consultas2
            // 
            this.Consultas2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConsultasLocalidades2,
            this.ConsultasContatos2,
            this.ConsultasAgenda2});
            this.Consultas2.Name = "Consultas2";
            this.Consultas2.Size = new System.Drawing.Size(126, 22);
            this.Consultas2.Text = "Consultas";
            // 
            // ConsultasLocalidades2
            // 
            this.ConsultasLocalidades2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConsultasLocalidadesCidades2,
            this.ConsultasLocalidadesEstados2,
            this.ConsultasLocalidadesPaises2});
            this.ConsultasLocalidades2.Name = "ConsultasLocalidades2";
            this.ConsultasLocalidades2.Size = new System.Drawing.Size(136, 22);
            this.ConsultasLocalidades2.Text = "Localidades";
            // 
            // ConsultasLocalidadesCidades2
            // 
            this.ConsultasLocalidadesCidades2.Name = "ConsultasLocalidadesCidades2";
            this.ConsultasLocalidadesCidades2.Size = new System.Drawing.Size(116, 22);
            this.ConsultasLocalidadesCidades2.Text = "Cidades";
            // 
            // ConsultasLocalidadesEstados2
            // 
            this.ConsultasLocalidadesEstados2.Name = "ConsultasLocalidadesEstados2";
            this.ConsultasLocalidadesEstados2.Size = new System.Drawing.Size(116, 22);
            this.ConsultasLocalidadesEstados2.Text = "Estados";
            // 
            // ConsultasLocalidadesPaises2
            // 
            this.ConsultasLocalidadesPaises2.Name = "ConsultasLocalidadesPaises2";
            this.ConsultasLocalidadesPaises2.Size = new System.Drawing.Size(116, 22);
            this.ConsultasLocalidadesPaises2.Text = "Países";
            // 
            // ConsultasContatos2
            // 
            this.ConsultasContatos2.Name = "ConsultasContatos2";
            this.ConsultasContatos2.Size = new System.Drawing.Size(136, 22);
            this.ConsultasContatos2.Text = "Contatos";
            // 
            // ConsultasAgenda2
            // 
            this.ConsultasAgenda2.Name = "ConsultasAgenda2";
            this.ConsultasAgenda2.Size = new System.Drawing.Size(136, 22);
            this.ConsultasAgenda2.Text = "Agenda";
            // 
            // Relatorios2
            // 
            this.Relatorios2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosDocumentos2,
            this.RelatoriosLocalidades2,
            this.RelatoriosComunicacoes2,
            this.RelatoriosContatos2,
            this.RelatoriosAgenda2,
            this.toolStripMenuItem10,
            this.RelatoriosAcessos2});
            this.Relatorios2.Name = "Relatorios2";
            this.Relatorios2.Size = new System.Drawing.Size(126, 22);
            this.Relatorios2.Text = "Relatórios";
            // 
            // RelatoriosDocumentos2
            // 
            this.RelatoriosDocumentos2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosDocumentosPessoais2});
            this.RelatoriosDocumentos2.Name = "RelatoriosDocumentos2";
            this.RelatoriosDocumentos2.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosDocumentos2.Text = "Documentos Pessoais";
            // 
            // RelatoriosDocumentosPessoais2
            // 
            this.RelatoriosDocumentosPessoais2.Name = "RelatoriosDocumentosPessoais2";
            this.RelatoriosDocumentosPessoais2.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosDocumentosPessoais2.Text = "Documentos Pessoais";
            // 
            // RelatoriosLocalidades2
            // 
            this.RelatoriosLocalidades2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosTitulosEnderecos2,
            this.RelatoriosEnderecos2,
            this.RelatoriosBairros2,
            this.RelatoriosCidades2,
            this.RelatoriosEstados2,
            this.RelatoriosPaises2,
            this.RelatoriosContinentes2});
            this.RelatoriosLocalidades2.Name = "RelatoriosLocalidades2";
            this.RelatoriosLocalidades2.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosLocalidades2.Text = "Localidades";
            // 
            // RelatoriosTitulosEnderecos2
            // 
            this.RelatoriosTitulosEnderecos2.Name = "RelatoriosTitulosEnderecos2";
            this.RelatoriosTitulosEnderecos2.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosTitulosEnderecos2.Text = "Títulos";
            // 
            // RelatoriosEnderecos2
            // 
            this.RelatoriosEnderecos2.Name = "RelatoriosEnderecos2";
            this.RelatoriosEnderecos2.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosEnderecos2.Text = "Endereços";
            // 
            // RelatoriosBairros2
            // 
            this.RelatoriosBairros2.Name = "RelatoriosBairros2";
            this.RelatoriosBairros2.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosBairros2.Text = "Bairros";
            // 
            // RelatoriosCidades2
            // 
            this.RelatoriosCidades2.Name = "RelatoriosCidades2";
            this.RelatoriosCidades2.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosCidades2.Text = "Cidades";
            // 
            // RelatoriosEstados2
            // 
            this.RelatoriosEstados2.Name = "RelatoriosEstados2";
            this.RelatoriosEstados2.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosEstados2.Text = "Estados";
            // 
            // RelatoriosPaises2
            // 
            this.RelatoriosPaises2.Name = "RelatoriosPaises2";
            this.RelatoriosPaises2.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosPaises2.Text = "Países";
            // 
            // RelatoriosContinentes2
            // 
            this.RelatoriosContinentes2.Name = "RelatoriosContinentes2";
            this.RelatoriosContinentes2.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosContinentes2.Text = "Continentes";
            // 
            // RelatoriosComunicacoes2
            // 
            this.RelatoriosComunicacoes2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosTiposTelefones2,
            this.RelatoriosTiposComunicacoes2});
            this.RelatoriosComunicacoes2.Name = "RelatoriosComunicacoes2";
            this.RelatoriosComunicacoes2.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosComunicacoes2.Text = "Comunicações";
            // 
            // RelatoriosTiposTelefones2
            // 
            this.RelatoriosTiposTelefones2.Name = "RelatoriosTiposTelefones2";
            this.RelatoriosTiposTelefones2.Size = new System.Drawing.Size(200, 22);
            this.RelatoriosTiposTelefones2.Text = "Tipos de Telefones";
            // 
            // RelatoriosTiposComunicacoes2
            // 
            this.RelatoriosTiposComunicacoes2.Name = "RelatoriosTiposComunicacoes2";
            this.RelatoriosTiposComunicacoes2.Size = new System.Drawing.Size(200, 22);
            this.RelatoriosTiposComunicacoes2.Text = "Tipos de Comunicações";
            // 
            // RelatoriosContatos2
            // 
            this.RelatoriosContatos2.Name = "RelatoriosContatos2";
            this.RelatoriosContatos2.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosContatos2.Text = "Contatos";
            // 
            // RelatoriosAgenda2
            // 
            this.RelatoriosAgenda2.Name = "RelatoriosAgenda2";
            this.RelatoriosAgenda2.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosAgenda2.Text = "Agenda";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(186, 6);
            // 
            // RelatoriosAcessos2
            // 
            this.RelatoriosAcessos2.Name = "RelatoriosAcessos2";
            this.RelatoriosAcessos2.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosAcessos2.Text = "Acessos";
            // 
            // Utilitarios2
            // 
            this.Utilitarios2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UtilitariosImpressora2,
            this.toolStripMenuItem4,
            this.UtilitariosVersao2,
            this.toolStripMenuItem5,
            this.UtilitariosTexto2,
            this.UtilitariosPublico2});
            this.Utilitarios2.Name = "Utilitarios2";
            this.Utilitarios2.Size = new System.Drawing.Size(126, 22);
            this.Utilitarios2.Text = "Utilitários";
            // 
            // UtilitariosImpressora2
            // 
            this.UtilitariosImpressora2.Name = "UtilitariosImpressora2";
            this.UtilitariosImpressora2.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosImpressora2.Text = "Impressora";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(129, 6);
            // 
            // UtilitariosVersao2
            // 
            this.UtilitariosVersao2.Name = "UtilitariosVersao2";
            this.UtilitariosVersao2.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosVersao2.Text = "Versão";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(129, 6);
            // 
            // UtilitariosTexto2
            // 
            this.UtilitariosTexto2.Name = "UtilitariosTexto2";
            this.UtilitariosTexto2.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosTexto2.Text = "Texto";
            this.UtilitariosTexto2.Visible = false;
            // 
            // UtilitariosPublico2
            // 
            this.UtilitariosPublico2.Name = "UtilitariosPublico2";
            this.UtilitariosPublico2.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosPublico2.Text = "Público";
            this.UtilitariosPublico2.Visible = false;
            // 
            // Conexao2
            // 
            this.Conexao2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConexaoConectar2,
            this.ConexaoConectarComo2,
            this.ConexaoDesconectar2,
            this.toolStripMenuItem6,
            this.ConexaoConfiguracoes2,
            this.toolStripMenuItem8,
            this.ConexaoAtualizarPermissoes2});
            this.Conexao2.Name = "Conexao2";
            this.Conexao2.Size = new System.Drawing.Size(126, 22);
            this.Conexao2.Text = "Conexão";
            // 
            // ConexaoConectar2
            // 
            this.ConexaoConectar2.Name = "ConexaoConectar2";
            this.ConexaoConectar2.Size = new System.Drawing.Size(182, 22);
            this.ConexaoConectar2.Text = "Conectar";
            // 
            // ConexaoConectarComo2
            // 
            this.ConexaoConectarComo2.Name = "ConexaoConectarComo2";
            this.ConexaoConectarComo2.Size = new System.Drawing.Size(182, 22);
            this.ConexaoConectarComo2.Text = "Conectar como...";
            // 
            // ConexaoDesconectar2
            // 
            this.ConexaoDesconectar2.Name = "ConexaoDesconectar2";
            this.ConexaoDesconectar2.Size = new System.Drawing.Size(182, 22);
            this.ConexaoDesconectar2.Text = "Desconectar";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(179, 6);
            // 
            // ConexaoConfiguracoes2
            // 
            this.ConexaoConfiguracoes2.Name = "ConexaoConfiguracoes2";
            this.ConexaoConfiguracoes2.Size = new System.Drawing.Size(182, 22);
            this.ConexaoConfiguracoes2.Text = "Configurações";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(179, 6);
            // 
            // ConexaoAtualizarPermissoes2
            // 
            this.ConexaoAtualizarPermissoes2.Name = "ConexaoAtualizarPermissoes2";
            this.ConexaoAtualizarPermissoes2.Size = new System.Drawing.Size(182, 22);
            this.ConexaoAtualizarPermissoes2.Text = "Atualizar Permissões";
            // 
            // Saida2
            // 
            this.Saida2.Name = "Saida2";
            this.Saida2.Size = new System.Drawing.Size(126, 22);
            this.Saida2.Text = "Saída";
            // 
            // MenuMain
            // 
            this.MenuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Cadastros1,
            this.Consultas1,
            this.Relatorios1,
            this.Utilitarios1,
            this.Conexao1,
            this.Saida1});
            this.MenuMain.Location = new System.Drawing.Point(0, 0);
            this.MenuMain.Name = "MenuMain";
            this.MenuMain.Size = new System.Drawing.Size(514, 24);
            this.MenuMain.TabIndex = 8;
            // 
            // Cadastros1
            // 
            this.Cadastros1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosDocumentos1,
            this.CadastrosLocalidades1,
            this.CadastrosComunicacoes1,
            this.CadastrosContatos1,
            this.CadastrosAgenda1});
            this.Cadastros1.Name = "Cadastros1";
            this.Cadastros1.Size = new System.Drawing.Size(71, 20);
            this.Cadastros1.Text = "Cadastros";
            // 
            // CadastrosDocumentos1
            // 
            this.CadastrosDocumentos1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosDocumentosPessoais1});
            this.CadastrosDocumentos1.Name = "CadastrosDocumentos1";
            this.CadastrosDocumentos1.Size = new System.Drawing.Size(153, 22);
            this.CadastrosDocumentos1.Text = "Documentos";
            // 
            // CadastrosDocumentosPessoais1
            // 
            this.CadastrosDocumentosPessoais1.Name = "CadastrosDocumentosPessoais1";
            this.CadastrosDocumentosPessoais1.Size = new System.Drawing.Size(189, 22);
            this.CadastrosDocumentosPessoais1.Text = "Documentos Pessoais";
            // 
            // CadastrosLocalidades1
            // 
            this.CadastrosLocalidades1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosLocalidadesTitulos1,
            this.CadastrosLocalidadesEnderecos1,
            this.CadastrosLocalidadesBairros1,
            this.CadastrosLocalidadesCidades1,
            this.CadastrosLocalidadesEstados1,
            this.CadastrosLocalidadesPaises1,
            this.CadastrosLocalidadesContinentes1});
            this.CadastrosLocalidades1.Name = "CadastrosLocalidades1";
            this.CadastrosLocalidades1.Size = new System.Drawing.Size(153, 22);
            this.CadastrosLocalidades1.Text = "Localidades";
            // 
            // CadastrosLocalidadesTitulos1
            // 
            this.CadastrosLocalidadesTitulos1.Name = "CadastrosLocalidadesTitulos1";
            this.CadastrosLocalidadesTitulos1.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesTitulos1.Text = "Títulos";
            // 
            // CadastrosLocalidadesEnderecos1
            // 
            this.CadastrosLocalidadesEnderecos1.Name = "CadastrosLocalidadesEnderecos1";
            this.CadastrosLocalidadesEnderecos1.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesEnderecos1.Text = "Endereços";
            // 
            // CadastrosLocalidadesBairros1
            // 
            this.CadastrosLocalidadesBairros1.Name = "CadastrosLocalidadesBairros1";
            this.CadastrosLocalidadesBairros1.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesBairros1.Text = "Bairros";
            // 
            // CadastrosLocalidadesCidades1
            // 
            this.CadastrosLocalidadesCidades1.Name = "CadastrosLocalidadesCidades1";
            this.CadastrosLocalidadesCidades1.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesCidades1.Text = "Cidades";
            // 
            // CadastrosLocalidadesEstados1
            // 
            this.CadastrosLocalidadesEstados1.Name = "CadastrosLocalidadesEstados1";
            this.CadastrosLocalidadesEstados1.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesEstados1.Text = "Estados";
            // 
            // CadastrosLocalidadesPaises1
            // 
            this.CadastrosLocalidadesPaises1.Name = "CadastrosLocalidadesPaises1";
            this.CadastrosLocalidadesPaises1.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesPaises1.Text = "Países";
            // 
            // CadastrosLocalidadesContinentes1
            // 
            this.CadastrosLocalidadesContinentes1.Name = "CadastrosLocalidadesContinentes1";
            this.CadastrosLocalidadesContinentes1.Size = new System.Drawing.Size(138, 22);
            this.CadastrosLocalidadesContinentes1.Text = "Continentes";
            // 
            // CadastrosComunicacoes1
            // 
            this.CadastrosComunicacoes1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosComunicacoesTiposTelefones1,
            this.CadastrosComunicacoesTiposComunicacoes1});
            this.CadastrosComunicacoes1.Name = "CadastrosComunicacoes1";
            this.CadastrosComunicacoes1.Size = new System.Drawing.Size(153, 22);
            this.CadastrosComunicacoes1.Text = "Comunicações";
            // 
            // CadastrosComunicacoesTiposTelefones1
            // 
            this.CadastrosComunicacoesTiposTelefones1.Name = "CadastrosComunicacoesTiposTelefones1";
            this.CadastrosComunicacoesTiposTelefones1.Size = new System.Drawing.Size(200, 22);
            this.CadastrosComunicacoesTiposTelefones1.Text = "Tipos de Telefones";
            // 
            // CadastrosComunicacoesTiposComunicacoes1
            // 
            this.CadastrosComunicacoesTiposComunicacoes1.Name = "CadastrosComunicacoesTiposComunicacoes1";
            this.CadastrosComunicacoesTiposComunicacoes1.Size = new System.Drawing.Size(200, 22);
            this.CadastrosComunicacoesTiposComunicacoes1.Text = "Tipos de Comunicações";
            // 
            // CadastrosContatos1
            // 
            this.CadastrosContatos1.Name = "CadastrosContatos1";
            this.CadastrosContatos1.Size = new System.Drawing.Size(153, 22);
            this.CadastrosContatos1.Text = "Contatos";
            // 
            // CadastrosAgenda1
            // 
            this.CadastrosAgenda1.Name = "CadastrosAgenda1";
            this.CadastrosAgenda1.Size = new System.Drawing.Size(153, 22);
            this.CadastrosAgenda1.Text = "Agenda";
            // 
            // Consultas1
            // 
            this.Consultas1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConsultasLocalidades1,
            this.ConsultasContatos1,
            this.ConsultasAgenda1});
            this.Consultas1.Name = "Consultas1";
            this.Consultas1.Size = new System.Drawing.Size(71, 20);
            this.Consultas1.Text = "Consultas";
            // 
            // ConsultasLocalidades1
            // 
            this.ConsultasLocalidades1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConsultasLocalidadesCidades1,
            this.ConsultasLocalidadesEstados1,
            this.ConsultasLocalidadesPaises1});
            this.ConsultasLocalidades1.Name = "ConsultasLocalidades1";
            this.ConsultasLocalidades1.Size = new System.Drawing.Size(136, 22);
            this.ConsultasLocalidades1.Text = "Localidades";
            // 
            // ConsultasLocalidadesCidades1
            // 
            this.ConsultasLocalidadesCidades1.Name = "ConsultasLocalidadesCidades1";
            this.ConsultasLocalidadesCidades1.Size = new System.Drawing.Size(116, 22);
            this.ConsultasLocalidadesCidades1.Text = "Cidades";
            // 
            // ConsultasLocalidadesEstados1
            // 
            this.ConsultasLocalidadesEstados1.Name = "ConsultasLocalidadesEstados1";
            this.ConsultasLocalidadesEstados1.Size = new System.Drawing.Size(116, 22);
            this.ConsultasLocalidadesEstados1.Text = "Estados";
            // 
            // ConsultasLocalidadesPaises1
            // 
            this.ConsultasLocalidadesPaises1.Name = "ConsultasLocalidadesPaises1";
            this.ConsultasLocalidadesPaises1.Size = new System.Drawing.Size(116, 22);
            this.ConsultasLocalidadesPaises1.Text = "Países";
            // 
            // ConsultasContatos1
            // 
            this.ConsultasContatos1.Name = "ConsultasContatos1";
            this.ConsultasContatos1.Size = new System.Drawing.Size(136, 22);
            this.ConsultasContatos1.Text = "Contatos";
            // 
            // ConsultasAgenda1
            // 
            this.ConsultasAgenda1.Name = "ConsultasAgenda1";
            this.ConsultasAgenda1.Size = new System.Drawing.Size(136, 22);
            this.ConsultasAgenda1.Text = "Agenda";
            // 
            // Relatorios1
            // 
            this.Relatorios1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosDocumentos1,
            this.RelatoriosLocalidades1,
            this.RelatoriosComunicacoes1,
            this.RelatoriosContatos1,
            this.RelatoriosAgenda1,
            this.toolStripMenuItem9,
            this.RelatoriosAcessos1});
            this.Relatorios1.Name = "Relatorios1";
            this.Relatorios1.Size = new System.Drawing.Size(71, 20);
            this.Relatorios1.Text = "Relatórios";
            // 
            // RelatoriosDocumentos1
            // 
            this.RelatoriosDocumentos1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosDocumentosPessoais1});
            this.RelatoriosDocumentos1.Name = "RelatoriosDocumentos1";
            this.RelatoriosDocumentos1.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosDocumentos1.Text = "Documentos Pessoais";
            // 
            // RelatoriosDocumentosPessoais1
            // 
            this.RelatoriosDocumentosPessoais1.Name = "RelatoriosDocumentosPessoais1";
            this.RelatoriosDocumentosPessoais1.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosDocumentosPessoais1.Text = "Documentos Pessoais";
            // 
            // RelatoriosLocalidades1
            // 
            this.RelatoriosLocalidades1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosTitulosEnderecos1,
            this.RelatoriosEnderecos1,
            this.RelatoriosBairros1,
            this.RelatoriosCidades1,
            this.RelatoriosEstados1,
            this.RelatoriosPaises1,
            this.RelatoriosContinentes1});
            this.RelatoriosLocalidades1.Name = "RelatoriosLocalidades1";
            this.RelatoriosLocalidades1.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosLocalidades1.Text = "Localidades";
            // 
            // RelatoriosTitulosEnderecos1
            // 
            this.RelatoriosTitulosEnderecos1.Name = "RelatoriosTitulosEnderecos1";
            this.RelatoriosTitulosEnderecos1.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosTitulosEnderecos1.Text = "Títulos";
            // 
            // RelatoriosEnderecos1
            // 
            this.RelatoriosEnderecos1.Name = "RelatoriosEnderecos1";
            this.RelatoriosEnderecos1.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosEnderecos1.Text = "Endereços";
            // 
            // RelatoriosBairros1
            // 
            this.RelatoriosBairros1.Name = "RelatoriosBairros1";
            this.RelatoriosBairros1.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosBairros1.Text = "Bairros";
            // 
            // RelatoriosCidades1
            // 
            this.RelatoriosCidades1.Name = "RelatoriosCidades1";
            this.RelatoriosCidades1.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosCidades1.Text = "Cidades";
            // 
            // RelatoriosEstados1
            // 
            this.RelatoriosEstados1.Name = "RelatoriosEstados1";
            this.RelatoriosEstados1.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosEstados1.Text = "Estados";
            // 
            // RelatoriosPaises1
            // 
            this.RelatoriosPaises1.Name = "RelatoriosPaises1";
            this.RelatoriosPaises1.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosPaises1.Text = "Países";
            // 
            // RelatoriosContinentes1
            // 
            this.RelatoriosContinentes1.Name = "RelatoriosContinentes1";
            this.RelatoriosContinentes1.Size = new System.Drawing.Size(138, 22);
            this.RelatoriosContinentes1.Text = "Continentes";
            // 
            // RelatoriosComunicacoes1
            // 
            this.RelatoriosComunicacoes1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RelatoriosTiposTelefones1,
            this.RelatoriosTiposComunicacoes1});
            this.RelatoriosComunicacoes1.Name = "RelatoriosComunicacoes1";
            this.RelatoriosComunicacoes1.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosComunicacoes1.Text = "Comunicações";
            // 
            // RelatoriosTiposTelefones1
            // 
            this.RelatoriosTiposTelefones1.Name = "RelatoriosTiposTelefones1";
            this.RelatoriosTiposTelefones1.Size = new System.Drawing.Size(200, 22);
            this.RelatoriosTiposTelefones1.Text = "Tipos de Telefones";
            // 
            // RelatoriosTiposComunicacoes1
            // 
            this.RelatoriosTiposComunicacoes1.Name = "RelatoriosTiposComunicacoes1";
            this.RelatoriosTiposComunicacoes1.Size = new System.Drawing.Size(200, 22);
            this.RelatoriosTiposComunicacoes1.Text = "Tipos de Comunicações";
            // 
            // RelatoriosContatos1
            // 
            this.RelatoriosContatos1.Name = "RelatoriosContatos1";
            this.RelatoriosContatos1.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosContatos1.Text = "Contatos";
            // 
            // RelatoriosAgenda1
            // 
            this.RelatoriosAgenda1.Name = "RelatoriosAgenda1";
            this.RelatoriosAgenda1.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosAgenda1.Text = "Agenda";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(186, 6);
            // 
            // RelatoriosAcessos1
            // 
            this.RelatoriosAcessos1.Name = "RelatoriosAcessos1";
            this.RelatoriosAcessos1.Size = new System.Drawing.Size(189, 22);
            this.RelatoriosAcessos1.Text = "Acessos";
            // 
            // Utilitarios1
            // 
            this.Utilitarios1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UtilitariosImpressora1,
            this.toolStripMenuItem1,
            this.UtilitariosVersao1,
            this.toolStripMenuItem2,
            this.UtilitariosTexto1,
            this.UtilitariosPublico1});
            this.Utilitarios1.Name = "Utilitarios1";
            this.Utilitarios1.Size = new System.Drawing.Size(69, 20);
            this.Utilitarios1.Text = "Utilitários";
            // 
            // UtilitariosImpressora1
            // 
            this.UtilitariosImpressora1.Name = "UtilitariosImpressora1";
            this.UtilitariosImpressora1.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosImpressora1.Text = "Impressora";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(129, 6);
            // 
            // UtilitariosVersao1
            // 
            this.UtilitariosVersao1.Name = "UtilitariosVersao1";
            this.UtilitariosVersao1.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosVersao1.Text = "Versão";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(129, 6);
            // 
            // UtilitariosTexto1
            // 
            this.UtilitariosTexto1.Name = "UtilitariosTexto1";
            this.UtilitariosTexto1.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosTexto1.Text = "Texto";
            this.UtilitariosTexto1.Visible = false;
            // 
            // UtilitariosPublico1
            // 
            this.UtilitariosPublico1.Name = "UtilitariosPublico1";
            this.UtilitariosPublico1.Size = new System.Drawing.Size(132, 22);
            this.UtilitariosPublico1.Text = "Público";
            this.UtilitariosPublico1.Visible = false;
            // 
            // Conexao1
            // 
            this.Conexao1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConexaoConectar1,
            this.ConexaoConectarComo1,
            this.ConexaoDesconectar1,
            this.toolStripMenuItem3,
            this.ConexaoConfiguracoes1,
            this.toolStripMenuItem7,
            this.ConexaoAtualizarPermissoes1});
            this.Conexao1.Name = "Conexao1";
            this.Conexao1.Size = new System.Drawing.Size(66, 20);
            this.Conexao1.Text = "Conexão";
            // 
            // ConexaoConectar1
            // 
            this.ConexaoConectar1.Name = "ConexaoConectar1";
            this.ConexaoConectar1.Size = new System.Drawing.Size(182, 22);
            this.ConexaoConectar1.Text = "Conectar";
            // 
            // ConexaoConectarComo1
            // 
            this.ConexaoConectarComo1.Name = "ConexaoConectarComo1";
            this.ConexaoConectarComo1.Size = new System.Drawing.Size(182, 22);
            this.ConexaoConectarComo1.Text = "Conectar como...";
            // 
            // ConexaoDesconectar1
            // 
            this.ConexaoDesconectar1.Name = "ConexaoDesconectar1";
            this.ConexaoDesconectar1.Size = new System.Drawing.Size(182, 22);
            this.ConexaoDesconectar1.Text = "Desconectar";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(179, 6);
            // 
            // ConexaoConfiguracoes1
            // 
            this.ConexaoConfiguracoes1.Name = "ConexaoConfiguracoes1";
            this.ConexaoConfiguracoes1.Size = new System.Drawing.Size(182, 22);
            this.ConexaoConfiguracoes1.Text = "Configurações";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(179, 6);
            // 
            // ConexaoAtualizarPermissoes1
            // 
            this.ConexaoAtualizarPermissoes1.Name = "ConexaoAtualizarPermissoes1";
            this.ConexaoAtualizarPermissoes1.Size = new System.Drawing.Size(182, 22);
            this.ConexaoAtualizarPermissoes1.Text = "Atualizar Permissões";
            this.ConexaoAtualizarPermissoes1.Click += new System.EventHandler(this.ConexaoAtualizarPermissoes1_Click);
            // 
            // Saida1
            // 
            this.Saida1.Name = "Saida1";
            this.Saida1.Size = new System.Drawing.Size(47, 20);
            this.Saida1.Text = "Saída";
            // 
            // PcBImagem
            // 
            this.PcBImagem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PcBImagem.Image = ((System.Drawing.Image)(resources.GetObject("PcBImagem.Image")));
            this.PcBImagem.Location = new System.Drawing.Point(0, 24);
            this.PcBImagem.Name = "PcBImagem";
            this.PcBImagem.Size = new System.Drawing.Size(514, 338);
            this.PcBImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PcBImagem.TabIndex = 9;
            this.PcBImagem.TabStop = false;
            // 
            // MainF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 362);
            this.ContextMenuStrip = this.MenuBotaoDireito;
            this.Controls.Add(this.PcBImagem);
            this.Controls.Add(this.MenuMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.MenuMain;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainF";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sample";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainF_FormClosing);
            this.MenuBotaoDireito.ResumeLayout(false);
            this.MenuMain.ResumeLayout(false);
            this.MenuMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcBImagem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip MenuBotaoDireito;
        private System.Windows.Forms.MenuStrip MenuMain;
        private System.Windows.Forms.ToolStripMenuItem Cadastros2;
        private System.Windows.Forms.ToolStripMenuItem Cadastros1;
        private System.Windows.Forms.ToolStripMenuItem Consultas2;
        private System.Windows.Forms.ToolStripMenuItem Consultas1;
        private System.Windows.Forms.ToolStripMenuItem Utilitarios2;
        private System.Windows.Forms.ToolStripMenuItem Utilitarios1;
        private System.Windows.Forms.ToolStripMenuItem Conexao2;
        private System.Windows.Forms.ToolStripMenuItem Conexao1;
        private System.Windows.Forms.ToolStripMenuItem Saida2;
        private System.Windows.Forms.ToolStripMenuItem Saida1;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosImpressora1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosVersao1;
        private System.Windows.Forms.ToolStripMenuItem ConexaoConectar1;
        private System.Windows.Forms.ToolStripMenuItem ConexaoConectarComo1;
        private System.Windows.Forms.ToolStripMenuItem ConexaoDesconectar1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem ConexaoConfiguracoes1;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosImpressora2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosVersao2;
        private System.Windows.Forms.ToolStripMenuItem ConexaoConectar2;
        private System.Windows.Forms.ToolStripMenuItem ConexaoConectarComo2;
        private System.Windows.Forms.ToolStripMenuItem ConexaoDesconectar2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem ConexaoConfiguracoes2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosDocumentos1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidades1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosComunicacoes1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosContatos1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosAgenda1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosDocumentos2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidades2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosComunicacoes2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosContatos2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosAgenda2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosDocumentosPessoais1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesTitulos1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesEnderecos1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesBairros1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesCidades1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesEstados1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesPaises1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesContinentes1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosComunicacoesTiposTelefones1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosComunicacoesTiposComunicacoes1;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidades1;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidadesCidades1;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidadesEstados1;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidadesPaises1;
        private System.Windows.Forms.ToolStripMenuItem ConsultasContatos1;
        private System.Windows.Forms.ToolStripMenuItem ConsultasAgenda1;
        private System.Windows.Forms.ToolStripMenuItem CadastrosDocumentosPessoais2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesTitulos2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesEnderecos2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesBairros2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesCidades2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesEstados2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesPaises2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosLocalidadesContinentes2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosComunicacoesTiposTelefones2;
        private System.Windows.Forms.ToolStripMenuItem CadastrosComunicacoesTiposComunicacoes2;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidades2;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidadesCidades2;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidadesEstados2;
        private System.Windows.Forms.ToolStripMenuItem ConsultasLocalidadesPaises2;
        private System.Windows.Forms.ToolStripMenuItem ConsultasContatos2;
        private System.Windows.Forms.ToolStripMenuItem ConsultasAgenda2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosTexto2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosTexto1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem ConexaoAtualizarPermissoes2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem ConexaoAtualizarPermissoes1;
        private System.Windows.Forms.ToolStripMenuItem Relatorios1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosDocumentos1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosDocumentosPessoais1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosLocalidades1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosTitulosEnderecos1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosEnderecos1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosBairros1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosCidades1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosEstados1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosPaises1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosContinentes1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosComunicacoes1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosTiposTelefones1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosTiposComunicacoes1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosContatos1;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosAgenda1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosAcessos1;
        private System.Windows.Forms.ToolStripMenuItem Relatorios2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosDocumentos2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosDocumentosPessoais2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosLocalidades2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosTitulosEnderecos2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosEnderecos2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosBairros2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosCidades2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosEstados2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosPaises2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosContinentes2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosComunicacoes2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosTiposTelefones2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosTiposComunicacoes2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosContatos2;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosAgenda2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem RelatoriosAcessos2;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosPublico2;
        private System.Windows.Forms.ToolStripMenuItem UtilitariosPublico1;
        private System.Windows.Forms.PictureBox PcBImagem;

    }
}