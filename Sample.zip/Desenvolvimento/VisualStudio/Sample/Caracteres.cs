﻿using System;
using System.Text;
using System.Globalization;

namespace Sample
{
    public sealed class Caracteres
    {
        public static string Aspas(string Valor)
        {
            string _Valor = "";

            _Valor = String.Concat("\"", Valor, "\"");

            return _Valor;
        }

        public static string RemoveAcentos(string Frase)
        {
            StringBuilder Retorno = new StringBuilder();

            if (String.IsNullOrEmpty(Frase) == false)
            {
                var MatrizTexto = Frase.Normalize(NormalizationForm.FormD).ToCharArray();

                foreach (char Letra in MatrizTexto)
                {
                    if (CharUnicodeInfo.GetUnicodeCategory(Letra) != UnicodeCategory.NonSpacingMark)
                        Retorno.Append(Letra);
                }
            }

            return Retorno.ToString();
        }

        public static string RemoveCifrao(string Frase)
        {
            StringBuilder Retorno = new StringBuilder();
            var MatrizTexto = Frase.Normalize(NormalizationForm.FormD).ToCharArray();

            foreach (char Letra in MatrizTexto)
            {
                if (Letra.ToString() != "$")
                    Retorno.Append(Letra);
            }

            return Retorno.ToString();
        }

        public static string EspacoBranco(string Texto, int EspacoBranco, Boolean Completar, Boolean Direita)
        {
            int Largura = 1;

            if (Completar == true)
                Largura = Texto.ToString().Length + 1;

            for (int i = Largura; i < EspacoBranco; i++)
			{
                if (Direita == true)
                    Texto = String.Concat(Texto, " ");
                else
                    Texto = String.Concat(" ", Texto);
            }

            return Texto;
        }
    }
}