﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Sample
{
    public sealed class ControlesDsk : IDisposable
    {
        #region Propriedades Internas

        #region Formulário

        private Form _Formulario;

        #endregion

        #region Itens de Menus

        private MenuStrip _MenuPrincipal;
        private ContextMenuStrip _MenuBotaoDireito;

        #endregion

        #region Retorno de Registros

        private BindingSource _FonteDados;
        private DataGridView _GradeDadosConfiguracoes;
        private DataGridView _GradeDadosCadastro;
        private DataGridView _GradeDadosConsulta;
        private DataGridView _GradeDadosConsultaDinamica;
        private DataGridView _GradeDadosComandoTexto;
        private DataGridView[] _GradeDadosRegistros;
        private Panel[] _Paineis;
        private ListBox _CaixaListagem;
        private ListBox _DGVCaixaListagem;

        #endregion

        #region Progressores e Contadores

        private ProgressBar _Medidor;

        #endregion

        #region Listas

        public List<Control> FormularioControles;

        #endregion

        #region Permissões e Acessos

        private TreeView _ArvoreItensMenus;

        #endregion

        #endregion

        #region Propriedades Externas

        #region Formulário

        public Form Formulario
        {
            get
            {
                return _Formulario;
            }
            set
            {
                _Formulario = value;
            }
        }

        #endregion

        #region Itens de Menus

        public MenuStrip MenuPrincipal
        {
            get
            {
                return _MenuPrincipal;
            }
            set
            {
                _MenuPrincipal = value;
            }
        }

        public ContextMenuStrip MenuBotaoDireito
        {
            get
            {
                return _MenuBotaoDireito;
            }
            set
            {
                _MenuBotaoDireito = value;
            }
        }

        #endregion

        #region Retorno de Registros

        public BindingSource FonteDados
        {
            get
            {
                return _FonteDados;
            }
            set
            {
                _FonteDados = value;
            }
        }

        public DataGridView GradeDadosConfiguracoes
        {
            get
            {
                return _GradeDadosConfiguracoes;
            }
            set
            {
                _GradeDadosConfiguracoes = value;
            }
        }

        public DataGridView GradeDadosCadastro
        {
            get
            {
                return _GradeDadosCadastro;
            }
            set
            {
                _GradeDadosCadastro = value;
            }
        }

        public DataGridView GradeDadosConsulta
        {
            get
            {
                return _GradeDadosConsulta;
            }
            set
            {
                _GradeDadosConsulta = value;
            }
        }

        public DataGridView GradeDadosConsultaDinamica
        {
            get
            {
                return _GradeDadosConsultaDinamica;
            }
            set
            {
                _GradeDadosConsultaDinamica = value;
            }
        }

        public DataGridView GradeDadosComandoTexto
        {
            get
            {
                return _GradeDadosComandoTexto;
            }
            set
            {
                _GradeDadosComandoTexto = value;
            }
        }

        public DataGridView[] GradeDadosRegistros
        {
            get
            {
                return _GradeDadosRegistros;
            }
            set
            {
                _GradeDadosRegistros = value;
            }
        }

        public Panel[] Paineis
        {
            get
            {
                return _Paineis;
            }
            set
            {
                _Paineis = value;
            }
        }

        public ListBox CaixaListagem
        {
            get
            {
                return _CaixaListagem;
            }
            set
            {
                _CaixaListagem = value;
            }
        }

        public ListBox DGVCaixaListagem
        {
            get
            {
                return _DGVCaixaListagem;
            }
            set
            {
                _DGVCaixaListagem = value;
            }
        }

        #endregion

        #region Progressores e Contadores

        public ProgressBar Medidor
        {
            get
            {
                return _Medidor;
            }
            set
            {
                _Medidor = value;
            }
        }

        #endregion

        #region Permissões e Acessos

        public TreeView ArvoreItensMenus
        {
            get
            {
                return _ArvoreItensMenus;
            }
            set
            {
                _ArvoreItensMenus = value;
            }
        }

        #endregion

        #endregion

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}