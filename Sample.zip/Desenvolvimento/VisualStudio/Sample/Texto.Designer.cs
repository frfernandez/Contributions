﻿namespace Sample
{
    partial class TextoF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TextoF));
            this.PnlTexto = new System.Windows.Forms.Panel();
            this.RcBTexto = new System.Windows.Forms.RichTextBox();
            this.PnlBotoes = new System.Windows.Forms.Panel();
            this.BtnSaida = new System.Windows.Forms.Button();
            this.TTpDica = new System.Windows.Forms.ToolTip(this.components);
            this.Imagens = new System.Windows.Forms.ImageList(this.components);
            this.PnlTexto.SuspendLayout();
            this.PnlBotoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlTexto
            // 
            this.PnlTexto.Controls.Add(this.RcBTexto);
            this.PnlTexto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlTexto.Location = new System.Drawing.Point(0, 0);
            this.PnlTexto.Name = "PnlTexto";
            this.PnlTexto.Size = new System.Drawing.Size(654, 311);
            this.PnlTexto.TabIndex = 0;
            // 
            // RcBTexto
            // 
            this.RcBTexto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RcBTexto.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RcBTexto.Location = new System.Drawing.Point(0, 0);
            this.RcBTexto.Name = "RcBTexto";
            this.RcBTexto.ReadOnly = true;
            this.RcBTexto.Size = new System.Drawing.Size(654, 311);
            this.RcBTexto.TabIndex = 1;
            this.RcBTexto.Text = "";
            // 
            // PnlBotoes
            // 
            this.PnlBotoes.Controls.Add(this.BtnSaida);
            this.PnlBotoes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PnlBotoes.Location = new System.Drawing.Point(0, 311);
            this.PnlBotoes.Name = "PnlBotoes";
            this.PnlBotoes.Size = new System.Drawing.Size(654, 51);
            this.PnlBotoes.TabIndex = 1;
            // 
            // BtnSaida
            // 
            this.BtnSaida.Location = new System.Drawing.Point(0, 0);
            this.BtnSaida.Name = "BtnSaida";
            this.BtnSaida.Size = new System.Drawing.Size(93, 50);
            this.BtnSaida.TabIndex = 2;
            this.BtnSaida.TabStop = false;
            this.BtnSaida.Text = "&Saída";
            this.TTpDica.SetToolTip(this.BtnSaida, "Retorna à tela anterior");
            this.BtnSaida.UseVisualStyleBackColor = true;
            this.BtnSaida.Click += new System.EventHandler(this.BtnSaida_Click);
            // 
            // Imagens
            // 
            this.Imagens.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Imagens.ImageStream")));
            this.Imagens.TransparentColor = System.Drawing.Color.Transparent;
            this.Imagens.Images.SetKeyName(0, "Saida-");
            this.Imagens.Images.SetKeyName(1, "Saida+");
            this.Imagens.Images.SetKeyName(2, "Seleciona-");
            this.Imagens.Images.SetKeyName(3, "Seleciona+");
            this.Imagens.Images.SetKeyName(4, "Limpa-");
            this.Imagens.Images.SetKeyName(5, "Limpa+");
            // 
            // TextoF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 362);
            this.Controls.Add(this.PnlTexto);
            this.Controls.Add(this.PnlBotoes);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TextoF";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Texto";
            this.Shown += new System.EventHandler(this.TextoF_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextoF_KeyDown);
            this.PnlTexto.ResumeLayout(false);
            this.PnlBotoes.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlTexto;
        private System.Windows.Forms.Panel PnlBotoes;
        private System.Windows.Forms.Button BtnSaida;
        private System.Windows.Forms.ToolTip TTpDica;
        private System.Windows.Forms.ImageList Imagens;
        public System.Windows.Forms.RichTextBox RcBTexto;
    }
}