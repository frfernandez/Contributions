﻿using System.Windows.Forms;

namespace Sample
{
    public partial class MainF : Form
    {
        public MainF()
        {
            InitializeComponent();
        }

        private void MainF_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
        }

        private void ConexaoAtualizarPermissoes1_Click(object sender, System.EventArgs e)
        {
            using (ItensMenuTabelasF Formulario = new ItensMenuTabelasF())
            {
                Formulario.ShowDialog();
                Formulario.Dispose();
            }
        }
    }
}