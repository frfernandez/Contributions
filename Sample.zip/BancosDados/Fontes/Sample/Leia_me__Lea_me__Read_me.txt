Português Brasileiro/Español/English
Desenvolvedor/Desarrollador/Developer: Fernando Roberto Fernández
Projeto/Proyecto/Project: Sample
Idioma/Idioma/Idiom: Português Brasileiro/Portugués Brasileño/Brazilian Portuguese
Bancos de Dados/Base de Datos/Database: InterBase/FireBird, SQL Server, Oracle

Português Brasileiro
Sample é um projeto padrão que faz parte de todos projetos particulares criados pelo desenvolvedor.
Quando jovem o desenvolvedor tinha em mente a idéia de criar uma empresa de programas de computadores onde a parte da segurança oferecida pelo banco de dados seria explorada.
Por particularidades da vida a empresa nunca foi criada e o projeto completo nunca foi colocado no mercado.
Depois trabalhar em várias empresas de tecnologia o desenvolvedor observou o uso excessivo da tecnologia de ponta nos programas, mas a segurança dos dados sendo deixada de lado. Em alguns casos a roda era reinventada de forma ineficiente.
Agora sem a idéia em mente de criar a empresa o desenvolvedor resolveu ajudar a comunidade tecnológica publicando os arquivos fontes dos objetos de banco de dados que controlam a segurança.
Acompanhando o projeto vem um programa desenvolvido em C# que ajuda a alimentar as tabelas e disparar seus gatilhos, bem como fazer uso de procedimentos armazenados e visões.

Español
Sample es un proyecto padrón que hace parte de todos los proyectos personales creados por el desarrollador.
Cuando jóven el desarrollador tenia la mente puesta en crear una compañía de programas informáticos donde la parte de la seguridad ofrecida por la base de datos seria explorada.
Por particularidades de la vida la compañía nunca fue creada y el proyecto completo nunca fue puesto en el mercado.
Después de trabajar en várias compañías de tecnología el desarrollador ha observado el uso excesivo de la tecnología de punta en los programas, pero la seguridad de los datos siendo dejada en otro rincón. En algunos casos la rueda era recreada de manera ineficiente.
Ahora sin la idea puesta en mente de crear la compañía el desarrollador ha resuelto ayudar a la comunidad tecnologica publicando los archivos fuentes de los objectos de la base de dados que controlan la seguridad.
Acompañando el proyecto viene un programa desarrollado en C# que ayuda en alimentar las tablas y a disparar sus gatillos, bien como hacer el uso de los procedimientos almacenados y visiones.

English
Sample is a default project make part of all particular projects created by developer.
When he was young the developer had a idea in mind to create a computer program company where the database security is explored.
Some particularities in the life never let the company be created and the complete project never come to the business.
After work in a lots of technology companies the developer saw a excessive cutting edge technology use in the programs but the data security was lay aside. In some cases the wheel was ewcewarws in a ineficient way.
Now without the idea to create the company the developer settled to help the technological community publishing the database objects source code files that control the security.
Following the project comes a program developed in C# to help to feed the tables and pull the triggers, and use the stored procedures and visions.